import Link from "next/link";
import ProgramIcon from "./ProgramIcon";
import { getDictionary } from "@/lib/dictionaries";
import { localeHref } from "@/lib/paths";

export default function ProgramCard({ program, locale }) {
  const t = getDictionary(locale);
  const isGold = program.color === "gold";
  return (
    <div
      className={`group flex h-full flex-col rounded-xl border bg-white p-6 shadow-card transition-shadow hover:shadow-lg ${
        isGold ? "border-gold-200" : "border-navy-100"
      }`}
    >
      <div className="flex items-start justify-between gap-3">
        <div
          className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-lg ${
            isGold ? "bg-gold-50 text-gold-600" : "bg-navy-50 text-navy-700"
          }`}
        >
          <ProgramIcon type={program.icon} />
        </div>
        <span
          className={`rounded-full px-2.5 py-1 text-xs font-semibold ${
            isGold ? "bg-gold-500 text-navy-900" : "bg-navy-800 text-white"
          }`}
        >
          {program.classLabel[locale]}
        </span>
      </div>

      <h3 className="mt-4 font-serif text-lg font-semibold leading-snug text-navy-900">{program.shortName[locale]}</h3>
      <p className="mt-1.5 text-sm leading-relaxed text-slate2">{program.tagline[locale]}</p>

      <div className="mt-4 flex flex-1 flex-wrap content-start gap-1.5">
        {program.subjects.slice(0, 4).map((s) => (
          <span key={s.en} className="rounded-full border border-navy-100 bg-paper px-2.5 py-1 text-xs text-navy-700">
            {s[locale]}
          </span>
        ))}
      </div>

      <Link
        href={localeHref(locale, `/programs/${program.slug}`)}
        className="mt-5 inline-flex w-fit items-center gap-1.5 border-t border-navy-100 pt-4 text-sm font-semibold text-navy-800 group-hover:text-gold-600"
      >
        {t.common.viewProgramDetails}
        <svg width="14" height="14" viewBox="0 0 16 16" fill="none" aria-hidden="true">
          <path d="M3 8H13M13 8L9 4M13 8L9 12" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      </Link>
    </div>
  );
}

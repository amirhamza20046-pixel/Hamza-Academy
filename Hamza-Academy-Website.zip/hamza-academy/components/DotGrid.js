// A quiet dot-grid texture — adds a touch of premium polish behind the hero
// without a photo to host/optimise. Pure SVG, pointer-events disabled.
export default function DotGrid({ className = "" }) {
  return (
    <svg
      className={`pointer-events-none absolute inset-0 h-full w-full ${className}`}
      aria-hidden="true"
      xmlns="http://www.w3.org/2000/svg"
    >
      <defs>
        <pattern id="hamza-dot-grid" width="22" height="22" patternUnits="userSpaceOnUse">
          <circle cx="1.5" cy="1.5" r="1.5" fill="currentColor" />
        </pattern>
      </defs>
      <rect width="100%" height="100%" fill="url(#hamza-dot-grid)" />
    </svg>
  );
}

import PageHero from "@/components/PageHero";
import Container from "@/components/Container";
import SectionHeading from "@/components/SectionHeading";
import { results, topPerformers } from "@/data/results";
import { getDictionary, formatDate } from "@/lib/dictionaries";

export default function ResultsView({ locale }) {
  const t = getDictionary(locale);
  const r = t.results;

  return (
    <div>
      <PageHero kicker={r.kicker} title={r.title} description={r.desc} />
      <Container className="py-14 sm:py-16">
        <SectionHeading eyebrow={r.sheetsEyebrow} title={r.sheetsTitle} />
        <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {results.map((res) => (
            <div key={res.id} className="rounded-lg border border-navy-100 bg-white p-5 shadow-card">
              <p className="text-xs font-semibold text-gold-600">{res.program[locale]}</p>
              <h3 className="mt-1 font-serif text-base font-semibold text-navy-900">{res.title[locale]}</h3>
              <p className="mt-1 text-xs text-slate2">{formatDate(res.date, locale)}</p>
              <a href={res.link} className="mt-3 inline-block text-sm font-semibold text-navy-700 hover:text-gold-600">
                {res.linkLabel[locale]} →
              </a>
            </div>
          ))}
        </div>

        <div className="mt-14">
          <SectionHeading eyebrow={r.topEyebrow} title={r.topTitle} />
          <div className="mt-6 grid gap-4 sm:grid-cols-3">
            {topPerformers.map((p) => (
              <div key={p.id} className="rounded-lg border border-gold-200 bg-gold-50 p-5">
                <h3 className="font-serif text-base font-semibold text-navy-900">{p.name[locale]}</h3>
                <p className="mt-1 text-xs font-medium text-gold-700">{p.program[locale]}</p>
                <p className="mt-2 text-sm text-navy-800">{p.note[locale]}</p>
              </div>
            ))}
          </div>
        </div>
      </Container>
    </div>
  );
}

import PageHero from "@/components/PageHero";
import Container from "@/components/Container";
import { routine } from "@/data/routine";
import { getDictionary, formatDate } from "@/lib/dictionaries";

export default function RoutineView({ locale }) {
  const t = getDictionary(locale);
  const r = t.routine;

  return (
    <div>
      <PageHero kicker={r.kicker} title={r.title} description={r.desc} />
      <Container className="py-14 sm:py-16">
        <div className="overflow-x-auto rounded-lg border border-navy-100 bg-white shadow-card">
          <table className="w-full min-w-[760px] text-left text-sm">
            <thead className="bg-navy-50 text-navy-800">
              <tr>
                <th className="px-4 py-3 font-semibold">{t.table.date}</th>
                <th className="px-4 py-3 font-semibold">{t.table.day}</th>
                <th className="px-4 py-3 font-semibold">{t.table.program}</th>
                <th className="px-4 py-3 font-semibold">{t.table.subject}</th>
                <th className="px-4 py-3 font-semibold">{t.table.topic}</th>
                <th className="px-4 py-3 font-semibold">{t.table.time}</th>
                <th className="px-4 py-3 font-semibold">{t.table.platform}</th>
              </tr>
            </thead>
            <tbody>
              {routine.map((row, i) => (
                <tr key={i} className="border-t border-navy-100">
                  <td className="px-4 py-3 text-navy-800">{formatDate(row.date, locale, { day: "numeric", month: "short" })}</td>
                  <td className="px-4 py-3 text-navy-800">{row.day[locale]}</td>
                  <td className="px-4 py-3 text-navy-800">{row.program[locale]}</td>
                  <td className="px-4 py-3 text-slate2">{row.subject[locale]}</td>
                  <td className="px-4 py-3 text-slate2">{row.topic[locale]}</td>
                  <td className="px-4 py-3 text-slate2">{row.time}</td>
                  <td className="px-4 py-3 text-slate2">{row.platform[locale]}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <p className="mt-4 text-xs text-slate2">{r.editHint}</p>
      </Container>
    </div>
  );
}

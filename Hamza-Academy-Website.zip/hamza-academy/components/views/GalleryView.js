import PageHero from "@/components/PageHero";
import Container from "@/components/Container";
import { galleryItems } from "@/data/gallery";
import { getDictionary } from "@/lib/dictionaries";

export default function GalleryView({ locale }) {
  const t = getDictionary(locale);
  const g = t.gallery;

  return (
    <div>
      <PageHero kicker={g.kicker} title={g.title} description={g.desc} />
      <Container className="py-14 sm:py-16">
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
          {galleryItems.map((item) => (
            <div
              key={item.id}
              className="flex aspect-square flex-col items-center justify-center gap-2 rounded-lg border border-dashed border-navy-200 bg-navy-50 p-4 text-center"
            >
              <svg width="28" height="28" viewBox="0 0 24 24" fill="none" className="text-navy-400" aria-hidden="true">
                <rect x="3" y="5" width="18" height="14" rx="2" stroke="currentColor" strokeWidth="1.5" />
                <circle cx="8.5" cy="10" r="1.5" stroke="currentColor" strokeWidth="1.5" />
                <path d="M21 16L15.5 11L6 19" stroke="currentColor" strokeWidth="1.5" />
              </svg>
              <p className="text-xs font-medium text-navy-600">{item.label[locale]}</p>
              <p className="text-[11px] text-slate2">{item.category[locale]}</p>
            </div>
          ))}
        </div>
        <p className="mt-8 text-xs text-slate2">{g.editHint}</p>
      </Container>
    </div>
  );
}

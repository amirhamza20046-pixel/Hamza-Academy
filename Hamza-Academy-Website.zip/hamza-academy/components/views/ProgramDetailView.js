import Link from "next/link";
import PageHero from "@/components/PageHero";
import Container from "@/components/Container";
import { getDictionary } from "@/lib/dictionaries";
import { localeHref } from "@/lib/paths";

export default function ProgramDetailView({ locale, program }) {
  const t = getDictionary(locale);
  const p = t.programs;

  return (
    <div>
      <PageHero kicker={p.kicker} title={program.name[locale]} description={program.tagline[locale]} />

      <Container className="grid gap-12 py-14 sm:py-16 lg:grid-cols-3">
        <div className="space-y-10 lg:col-span-2">
          <section>
            <h2 className="font-serif text-xl font-semibold text-navy-900">{p.detailOverview}</h2>
            <p className="mt-3 text-base leading-relaxed text-slate2">{program.overview[locale]}</p>
          </section>

          <section>
            <h2 className="font-serif text-xl font-semibold text-navy-900">{p.detailTarget}</h2>
            <p className="mt-3 text-base leading-relaxed text-slate2">{program.target[locale]}</p>
          </section>

          <section>
            <h2 className="font-serif text-xl font-semibold text-navy-900">{p.detailSubjects}</h2>
            <div className="mt-3 flex flex-wrap gap-2">
              {program.subjects.map((s) => (
                <span key={s.en} className="rounded-full border border-navy-200 bg-navy-50 px-3 py-1.5 text-sm text-navy-800">
                  {s[locale]}
                </span>
              ))}
            </div>
          </section>

          <section>
            <h2 className="font-serif text-xl font-semibold text-navy-900">{p.detailBenefits}</h2>
            <ul className="mt-3 space-y-2">
              {program.benefits.map((b) => (
                <li key={b.en} className="flex items-start gap-3 text-sm leading-relaxed text-navy-800">
                  <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-gold-500" />
                  {b[locale]}
                </li>
              ))}
            </ul>
          </section>

          <section>
            <h2 className="font-serif text-xl font-semibold text-navy-900">{p.detailMethod}</h2>
            <p className="mt-3 text-base leading-relaxed text-slate2">{program.method[locale]}</p>
          </section>
        </div>

        <aside>
          <div className="sticky top-24 rounded-lg border border-navy-100 bg-white p-6 shadow-card">
            <h3 className="font-serif text-lg font-semibold text-navy-900">{p.sidebarTitle}</h3>
            <p className="mt-2 text-sm leading-relaxed text-slate2">{p.sidebarBody}</p>
            <Link
              href={localeHref(locale, "/admission")}
              className="mt-5 block rounded-md bg-navy-800 px-5 py-3 text-center text-sm font-semibold text-white hover:bg-navy-900"
            >
              {p.admissionBtn}
            </Link>
            <Link
              href={localeHref(locale, "/programs")}
              className="mt-3 block rounded-md border border-navy-200 px-5 py-3 text-center text-sm font-semibold text-navy-800 hover:border-navy-400"
            >
              {p.backLink}
            </Link>
          </div>
        </aside>
      </Container>
    </div>
  );
}

import PageHero from "@/components/PageHero";
import Container from "@/components/Container";
import SectionHeading from "@/components/SectionHeading";
import { routine } from "@/data/routine";
import { getDictionary } from "@/lib/dictionaries";

export default function OnlineClassesView({ locale }) {
  const t = getDictionary(locale);
  const o = t.onlineClasses;

  return (
    <div>
      <PageHero kicker={o.kicker} title={o.title} description={o.desc} />

      <Container className="py-14 sm:py-16">
        <SectionHeading eyebrow={o.platformsEyebrow} title={o.platformsTitle} />
        <div className="mt-6 grid gap-6 sm:grid-cols-2">
          <div className="rounded-lg border border-navy-100 bg-white p-6 shadow-card">
            <h3 className="font-serif text-lg font-semibold text-navy-900">{o.meetTitle}</h3>
            <p className="mt-2 text-sm leading-relaxed text-slate2">{o.meetBody}</p>
          </div>
          <div className="rounded-lg border border-navy-100 bg-white p-6 shadow-card">
            <h3 className="font-serif text-lg font-semibold text-navy-900">{o.zoomTitle}</h3>
            <p className="mt-2 text-sm leading-relaxed text-slate2">{o.zoomBody}</p>
          </div>
        </div>

        <div className="mt-14">
          <SectionHeading eyebrow={o.upcomingEyebrow} title={o.upcomingTitle} />
          <div className="mt-6 overflow-x-auto rounded-lg border border-navy-100 bg-white shadow-card">
            <table className="w-full min-w-[600px] text-left text-sm">
              <thead className="bg-navy-50 text-navy-800">
                <tr>
                  <th className="px-4 py-3 font-semibold">{t.table.program}</th>
                  <th className="px-4 py-3 font-semibold">{t.table.subject}</th>
                  <th className="px-4 py-3 font-semibold">{t.table.time}</th>
                  <th className="px-4 py-3 font-semibold">{t.table.platform}</th>
                </tr>
              </thead>
              <tbody>
                {routine.slice(0, 4).map((row, i) => (
                  <tr key={i} className="border-t border-navy-100">
                    <td className="px-4 py-3 text-navy-800">{row.program[locale]}</td>
                    <td className="px-4 py-3 text-slate2">{row.subject[locale]}</td>
                    <td className="px-4 py-3 text-slate2">{row.time}</td>
                    <td className="px-4 py-3 text-slate2">{row.platform[locale]}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="mt-14">
          <SectionHeading eyebrow={o.stepsEyebrow} title={o.stepsTitle} />
          <ol className="mt-6 space-y-5">
            {o.steps.map((step, i) => (
              <li key={step.title} className="flex gap-4 rounded-lg border border-navy-100 bg-white p-5 shadow-card">
                <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-navy-800 text-sm font-semibold text-white">
                  {i + 1}
                </span>
                <div>
                  <h3 className="font-serif text-base font-semibold text-navy-900">{step.title}</h3>
                  <p className="mt-1 text-sm leading-relaxed text-slate2">{step.body}</p>
                </div>
              </li>
            ))}
          </ol>
        </div>

        <div className="mt-14">
          <SectionHeading eyebrow={o.guidelinesEyebrow} title={o.guidelinesTitle} />
          <ul className="mt-6 space-y-3">
            {o.guidelines.map((g) => (
              <li key={g} className="flex items-start gap-3 rounded-lg bg-navy-50 p-4 text-sm leading-relaxed text-navy-800">
                <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-gold-500" />
                {g}
              </li>
            ))}
          </ul>
        </div>
      </Container>
    </div>
  );
}

import PageHero from "@/components/PageHero";
import Container from "@/components/Container";
import ContactForm from "@/components/ContactForm";
import { site } from "@/data/site";
import { getDictionary } from "@/lib/dictionaries";

export default function ContactView({ locale }) {
  const t = getDictionary(locale);
  const c = t.contact;
  const address = locale === "bn" ? site.addressBn : site.address;
  const brandName = locale === "bn" ? site.nameBn : site.name;

  return (
    <div>
      <PageHero kicker={c.kicker} title={c.title} description={c.desc} />
      <Container className="grid gap-10 py-14 sm:py-16 lg:grid-cols-5">
        <div className="lg:col-span-3">
          <ContactForm locale={locale} />
        </div>

        <div className="space-y-6 lg:col-span-2">
          <div className="rounded-lg border border-navy-100 bg-white p-6 shadow-card">
            <h3 className="font-serif text-lg font-semibold text-navy-900">{brandName}</h3>
            <ul className="mt-4 space-y-3 text-sm text-slate2">
              <li>{address}</li>
              <li>
                <a href={`tel:${site.phone}`} className="hover:text-navy-800">{site.phone}</a>
              </li>
              <li>
                <a href={`mailto:${site.email}`} className="hover:text-navy-800">{site.email}</a>
              </li>
            </ul>
            <div className="mt-5 flex gap-4 text-sm font-medium text-navy-700">
              <a href={site.social.facebook} target="_blank" rel="noopener noreferrer" className="hover:text-gold-600">Facebook</a>
              <a href={site.social.instagram} target="_blank" rel="noopener noreferrer" className="hover:text-gold-600">Instagram</a>
              <a href={site.social.youtube} target="_blank" rel="noopener noreferrer" className="hover:text-gold-600">YouTube</a>
            </div>
          </div>

          <div className="overflow-hidden rounded-lg border border-navy-100 bg-navy-50">
            <div className="flex h-48 items-center justify-center px-4 text-center text-sm text-slate2">
              {c.mapPlaceholder}
            </div>
          </div>
        </div>
      </Container>
    </div>
  );
}

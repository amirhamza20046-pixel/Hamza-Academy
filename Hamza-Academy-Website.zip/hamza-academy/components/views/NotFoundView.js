import Link from "next/link";
import Container from "@/components/Container";
import { getDictionary } from "@/lib/dictionaries";
import { localeHref } from "@/lib/paths";

export default function NotFoundView({ locale = "bn" }) {
  const t = getDictionary(locale);
  const nf = t.notFound;

  return (
    <Container className="flex flex-col items-center justify-center gap-4 py-24 text-center">
      <p className="text-sm font-semibold text-gold-600">404</p>
      <h1 className="font-serif text-3xl font-semibold text-navy-900">{nf.title}</h1>
      <p className="max-w-sm text-sm text-slate2">{nf.body}</p>
      <Link href={localeHref(locale, "/")} className="mt-2 rounded-md bg-navy-800 px-6 py-3 text-sm font-semibold text-white hover:bg-navy-900">
        {nf.button}
      </Link>
    </Container>
  );
}

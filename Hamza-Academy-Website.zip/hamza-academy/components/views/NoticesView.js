import PageHero from "@/components/PageHero";
import Container from "@/components/Container";
import NoticeCard from "@/components/NoticeCard";
import { notices } from "@/data/notices";
import { getDictionary } from "@/lib/dictionaries";

export default function NoticesView({ locale }) {
  const t = getDictionary(locale);
  const n = t.notices;

  return (
    <div>
      <PageHero kicker={n.kicker} title={n.title} description={n.desc} />
      <Container className="py-14 sm:py-16">
        <div className="space-y-4">
          {notices.map((notice) => (
            <NoticeCard key={notice.id} notice={notice} locale={locale} />
          ))}
        </div>
      </Container>
    </div>
  );
}

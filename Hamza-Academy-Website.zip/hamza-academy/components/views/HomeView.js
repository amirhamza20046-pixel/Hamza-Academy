import Link from "next/link";
import Container from "@/components/Container";
import SectionHeading from "@/components/SectionHeading";
import ProgramCard from "@/components/ProgramCard";
import NoticeCard from "@/components/NoticeCard";
import TeacherCard from "@/components/TeacherCard";
import TestimonialCard from "@/components/TestimonialCard";
import HeroGraphic from "@/components/HeroGraphic";
import DotGrid from "@/components/DotGrid";
import { programs } from "@/data/programs";
import { notices } from "@/data/notices";
import { routine } from "@/data/routine";
import { materialCategories } from "@/data/materials";
import { results } from "@/data/results";
import { teachers } from "@/data/teachers";
import { testimonials } from "@/data/testimonials";
import { site } from "@/data/site";
import { getDictionary } from "@/lib/dictionaries";
import { localeHref } from "@/lib/paths";

export default function HomeView({ locale }) {
  const t = getDictionary(locale);
  const brandName = locale === "bn" ? site.nameBn : site.name;

  return (
    <div>
      {/* Hero */}
      <section className="relative overflow-hidden border-b border-navy-100 bg-paper">
        <DotGrid className="left-0 top-0 hidden h-[420px] w-[420px] text-navy-100 opacity-70 lg:block" />
        <Container className="relative grid items-center gap-10 py-14 sm:py-20 lg:grid-cols-2 lg:gap-16">
          <div>
            <div className="flex items-center gap-2">
              <span className="h-[3px] w-6 rounded-full bg-gold-500" aria-hidden="true" />
              <p className="text-sm font-semibold tracking-wide text-gold-600">{t.home.heroEyebrow}</p>
            </div>
            <h1 className="mt-4 font-serif text-4xl font-bold leading-[1.15] tracking-tight text-navy-900 sm:text-5xl lg:text-6xl">
              {brandName}
            </h1>
            <p className="mt-4 text-lg font-medium text-navy-700">{t.home.heroBanglaSub}</p>
            <p className="mt-4 max-w-lg text-base leading-relaxed text-slate2">{t.home.heroDesc}</p>
            <div className="mt-8 flex flex-col gap-3 sm:flex-row">
              <Link
                href={localeHref(locale, "/admission")}
                className="rounded-md bg-navy-800 px-6 py-3 text-center text-sm font-semibold text-white shadow-sm transition-colors hover:bg-navy-900"
              >
                {t.common.admissionInfo}
              </Link>
              <Link
                href={localeHref(locale, "/programs")}
                className="rounded-md border border-navy-300 bg-white px-6 py-3 text-center text-sm font-semibold text-navy-800 transition-colors hover:border-navy-500"
              >
                {t.common.exploreProgams}
              </Link>
            </div>

            <dl className="mt-10 grid max-w-lg grid-cols-2 gap-x-6 gap-y-5 border-t border-navy-100 pt-6 sm:grid-cols-4 sm:gap-x-4">
              {[
                [t.home.stat1Value, t.home.stat1Label],
                [t.home.stat2Value, t.home.stat2Label],
                [t.home.stat3Value, t.home.stat3Label],
                [t.home.stat4Value, t.home.stat4Label]
              ].map(([value, label]) => (
                <div key={label}>
                  <dt className="font-serif text-xl font-bold text-navy-900">{value}</dt>
                  <dd className="mt-0.5 text-xs leading-snug text-slate2">{label}</dd>
                </div>
              ))}
            </dl>
          </div>
          <div className="flex justify-center lg:justify-end">
            <HeroGraphic />
          </div>
        </Container>
      </section>

      {/* Programs */}
      <section className="py-16 sm:py-20">
        <Container>
          <SectionHeading eyebrow={t.home.programsEyebrow} title={t.home.programsTitle} description={t.home.programsDesc} />
          <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {programs.map((program) => (
              <ProgramCard key={program.slug} program={program} locale={locale} />
            ))}
          </div>
        </Container>
      </section>

      {/* Why Choose Us + Online Learning Benefits */}
      <section className="bg-navy-900 py-16 text-white sm:py-20">
        <Container className="grid gap-12 lg:grid-cols-2">
          <div>
            <p className="text-sm font-semibold text-gold-400">{t.home.whyEyebrow}</p>
            <h2 className="mt-2 font-serif text-2xl font-semibold sm:text-3xl">{t.home.whyTitle}</h2>
            <ul className="mt-6 space-y-4">
              {t.home.whyPoints.map((point) => (
                <li key={point} className="flex items-start gap-3 text-navy-100">
                  <span className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-gold-500/15 text-gold-400">
                    <svg width="11" height="11" viewBox="0 0 12 12" fill="none" aria-hidden="true">
                      <path d="M2.5 6.2L4.8 8.5L9.5 3.5" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" />
                    </svg>
                  </span>
                  <span>{point}</span>
                </li>
              ))}
            </ul>
          </div>
          <div>
            <p className="text-sm font-semibold text-gold-400">{t.home.benefitsEyebrow}</p>
            <h2 className="mt-2 font-serif text-2xl font-semibold sm:text-3xl">{t.home.benefitsTitle}</h2>
            <div className="mt-6 grid gap-4 sm:grid-cols-2">
              {t.home.benefits.map((item) => (
                <div key={item.title} className="rounded-lg border border-navy-700 bg-navy-800 p-4">
                  <h3 className="font-serif text-base font-semibold text-white">{item.title}</h3>
                  <p className="mt-1.5 text-sm leading-relaxed text-navy-200">{item.body}</p>
                </div>
              ))}
            </div>
          </div>
        </Container>
      </section>

      {/* Latest Notices */}
      <section className="py-16 sm:py-20">
        <Container>
          <div className="flex flex-col items-start justify-between gap-4 sm:flex-row sm:items-end">
            <SectionHeading eyebrow={t.home.noticesEyebrow} title={t.home.noticesTitle} />
            <Link href={localeHref(locale, "/notices")} className="text-sm font-semibold text-navy-800 hover:text-gold-600">
              {t.home.viewAllNotices} →
            </Link>
          </div>
          <div className="mt-8 space-y-4">
            {notices.slice(0, 3).map((notice) => (
              <NoticeCard key={notice.id} notice={notice} locale={locale} />
            ))}
          </div>
        </Container>
      </section>

      {/* Class Routine Preview */}
      <section className="bg-white py-16 sm:py-20">
        <Container>
          <div className="flex flex-col items-start justify-between gap-4 sm:flex-row sm:items-end">
            <SectionHeading eyebrow={t.home.routineEyebrow} title={t.home.routineTitle} />
            <Link href={localeHref(locale, "/routine")} className="text-sm font-semibold text-navy-800 hover:text-gold-600">
              {t.home.viewFullRoutine} →
            </Link>
          </div>
          <div className="mt-8 overflow-x-auto rounded-lg border border-navy-100">
            <table className="w-full min-w-[640px] text-left text-sm">
              <thead className="bg-navy-50 text-navy-800">
                <tr>
                  <th className="px-4 py-3 font-semibold">{t.table.day}</th>
                  <th className="px-4 py-3 font-semibold">{t.table.program}</th>
                  <th className="px-4 py-3 font-semibold">{t.table.subject}</th>
                  <th className="px-4 py-3 font-semibold">{t.table.time}</th>
                  <th className="px-4 py-3 font-semibold">{t.table.platform}</th>
                </tr>
              </thead>
              <tbody>
                {routine.slice(0, 5).map((row, i) => (
                  <tr key={i} className="border-t border-navy-100">
                    <td className="px-4 py-3 text-navy-800">{row.day[locale]}</td>
                    <td className="px-4 py-3 text-navy-800">{row.program[locale]}</td>
                    <td className="px-4 py-3 text-slate2">{row.subject[locale]}</td>
                    <td className="px-4 py-3 text-slate2">{row.time}</td>
                    <td className="px-4 py-3 text-slate2">{row.platform[locale]}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Container>
      </section>

      {/* Featured Study Materials */}
      <section className="py-16 sm:py-20">
        <Container>
          <div className="flex flex-col items-start justify-between gap-4 sm:flex-row sm:items-end">
            <SectionHeading eyebrow={t.home.materialsEyebrow} title={t.home.materialsTitle} />
            <Link href={localeHref(locale, "/materials")} className="text-sm font-semibold text-navy-800 hover:text-gold-600">
              {t.home.browseAllMaterials} →
            </Link>
          </div>
          <div className="mt-8 grid gap-4 sm:grid-cols-2">
            {materialCategories
              .flatMap((c) => c.items.map((item) => ({ ...item, category: c.label })))
              .slice(0, 4)
              .map((item) => (
                <a
                  key={item.id}
                  href={item.link}
                  className="flex items-start justify-between gap-4 rounded-lg border border-navy-100 bg-white p-5 shadow-card transition-colors hover:border-navy-300"
                >
                  <div>
                    <p className="text-xs font-semibold text-gold-600">{item.category[locale]}</p>
                    <h3 className="mt-1 font-serif text-base font-semibold text-navy-900">{item.title[locale]}</h3>
                    <p className="mt-1 text-xs text-slate2">{item.program[locale]}</p>
                  </div>
                  <span className="mt-1 shrink-0 text-sm font-semibold text-navy-700">{t.common.download}</span>
                </a>
              ))}
          </div>
        </Container>
      </section>

      {/* Achievement / Results */}
      <section className="bg-navy-50 py-16 sm:py-20">
        <Container>
          <div className="flex flex-col items-start justify-between gap-4 sm:flex-row sm:items-end">
            <SectionHeading eyebrow={t.home.resultsEyebrow} title={t.home.resultsTitle} />
            <Link href={localeHref(locale, "/results")} className="text-sm font-semibold text-navy-800 hover:text-gold-600">
              {t.home.viewAllResults} →
            </Link>
          </div>
          <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {results.slice(0, 4).map((r) => (
              <div key={r.id} className="rounded-lg border border-navy-100 bg-white p-5 shadow-card">
                <p className="text-xs font-semibold text-gold-600">{r.program[locale]}</p>
                <h3 className="mt-1 font-serif text-sm font-semibold text-navy-900">{r.title[locale]}</h3>
                <a href={r.link} className="mt-3 inline-block text-sm font-semibold text-navy-700 hover:text-gold-600">
                  {r.linkLabel[locale]} →
                </a>
              </div>
            ))}
          </div>
        </Container>
      </section>

      {/* Teacher Introduction */}
      <section className="py-16 sm:py-20">
        <Container>
          <div className="flex flex-col items-start justify-between gap-4 sm:flex-row sm:items-end">
            <SectionHeading eyebrow={t.home.teachersEyebrow} title={t.home.teachersTitle} />
            <Link href={localeHref(locale, "/teachers")} className="text-sm font-semibold text-navy-800 hover:text-gold-600">
              {t.home.meetAllTeachers} →
            </Link>
          </div>
          <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {teachers.map((tch) => (
              <TeacherCard key={tch.id} teacher={tch} locale={locale} />
            ))}
          </div>
        </Container>
      </section>

      {/* Testimonials */}
      <section className="bg-white py-16 sm:py-20">
        <Container>
          <SectionHeading align="center" eyebrow={t.home.testimonialsEyebrow} title={t.home.testimonialsTitle} />
          <div className="mx-auto mt-10 grid max-w-5xl gap-6 sm:grid-cols-3">
            {testimonials.map((ts) => (
              <TestimonialCard key={ts.id} testimonial={ts} locale={locale} />
            ))}
          </div>
        </Container>
      </section>

      {/* Contact strip */}
      <section className="py-16 sm:py-20">
        <Container className="flex flex-col items-center justify-between gap-6 rounded-lg border border-navy-100 bg-navy-900 px-6 py-10 text-center sm:flex-row sm:text-left sm:px-10">
          <div>
            <h2 className="font-serif text-2xl font-semibold text-white">{t.home.ctaTitle}</h2>
            <p className="mt-2 max-w-md text-sm text-navy-200">{t.home.ctaDesc}</p>
          </div>
          <div className="flex flex-col gap-3 sm:flex-row">
            <Link
              href={localeHref(locale, "/admission")}
              className="rounded-md bg-gold-500 px-6 py-3 text-center text-sm font-semibold text-navy-900 transition-colors hover:bg-gold-400"
            >
              {t.home.ctaAdmission}
            </Link>
            <Link
              href={localeHref(locale, "/contact")}
              className="rounded-md border border-navy-600 px-6 py-3 text-center text-sm font-semibold text-white transition-colors hover:border-gold-400"
            >
              {t.home.ctaContact}
            </Link>
          </div>
        </Container>
      </section>
    </div>
  );
}

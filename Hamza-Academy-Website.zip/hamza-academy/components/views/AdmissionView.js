import PageHero from "@/components/PageHero";
import Container from "@/components/Container";
import AdmissionForm from "@/components/AdmissionForm";
import { programs } from "@/data/programs";
import { getDictionary } from "@/lib/dictionaries";

export default function AdmissionView({ locale }) {
  const t = getDictionary(locale);
  const a = t.admission;

  return (
    <div>
      <PageHero kicker={a.kicker} title={a.title} description={a.desc} />
      <Container className="grid gap-10 py-14 sm:py-16 lg:grid-cols-5">
        <div className="lg:col-span-3">
          <AdmissionForm locale={locale} />
        </div>

        <div className="space-y-4 lg:col-span-2">
          <h3 className="font-serif text-lg font-semibold text-navy-900">{a.availableProgramsTitle}</h3>
          {programs.map((p) => (
            <div key={p.slug} className="rounded-lg border border-navy-100 bg-white p-4 shadow-card">
              <h4 className="font-serif text-sm font-semibold text-navy-900">{p.shortName[locale]}</h4>
              <p className="mt-1 text-xs leading-relaxed text-slate2">{p.tagline[locale]}</p>
            </div>
          ))}
          <div className="rounded-lg bg-navy-50 p-4 text-sm text-navy-800">{a.callHint}</div>
        </div>
      </Container>
    </div>
  );
}

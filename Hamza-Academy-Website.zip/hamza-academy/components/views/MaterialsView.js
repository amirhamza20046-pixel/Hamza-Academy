import PageHero from "@/components/PageHero";
import Container from "@/components/Container";
import { materialCategories } from "@/data/materials";
import { getDictionary } from "@/lib/dictionaries";

export default function MaterialsView({ locale }) {
  const t = getDictionary(locale);
  const m = t.materials;

  return (
    <div>
      <PageHero kicker={m.kicker} title={m.title} description={m.desc} />
      <Container className="space-y-12 py-14 sm:py-16">
        {materialCategories.map((category) => (
          <div key={category.id}>
            <h2 className="font-serif text-xl font-semibold text-navy-900">{category.label[locale]}</h2>
            <div className="mt-5 grid gap-4 sm:grid-cols-2">
              {category.items.map((item) => (
                <a
                  key={item.id}
                  href={item.link}
                  className="flex items-center justify-between gap-4 rounded-lg border border-navy-100 bg-white p-5 shadow-card transition-colors hover:border-navy-300"
                >
                  <div>
                    <h3 className="font-serif text-base font-semibold text-navy-900">{item.title[locale]}</h3>
                    <p className="mt-1 text-xs text-slate2">{item.program[locale]}</p>
                  </div>
                  <span className="shrink-0 text-sm font-semibold text-navy-700">{t.common.download} →</span>
                </a>
              ))}
            </div>
          </div>
        ))}
        <p className="text-xs text-slate2">{m.editHint}</p>
      </Container>
    </div>
  );
}

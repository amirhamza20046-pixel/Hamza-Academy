import PageHero from "@/components/PageHero";
import Container from "@/components/Container";
import TeacherCard from "@/components/TeacherCard";
import { teachers } from "@/data/teachers";
import { getDictionary } from "@/lib/dictionaries";

export default function TeachersView({ locale }) {
  const t = getDictionary(locale);
  const tc = t.teachers;

  return (
    <div>
      <PageHero kicker={tc.kicker} title={tc.title} description={tc.desc} />
      <Container className="py-14 sm:py-16">
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {teachers.map((teacher) => (
            <TeacherCard key={teacher.id} teacher={teacher} locale={locale} />
          ))}
        </div>
        <p className="mt-8 text-xs text-slate2">{tc.editHint}</p>
      </Container>
    </div>
  );
}

import PageHero from "@/components/PageHero";
import Container from "@/components/Container";
import SectionHeading from "@/components/SectionHeading";
import Avatar from "@/components/Avatar";
import { getDictionary } from "@/lib/dictionaries";

export default function AboutView({ locale }) {
  const t = getDictionary(locale);
  const a = t.about;

  return (
    <div>
      <PageHero kicker={a.kicker} title={a.title} description={a.desc} />

      <Container className="grid gap-14 py-14 sm:py-16 lg:grid-cols-3">
        <div className="space-y-10 lg:col-span-2">
          <section>
            <SectionHeading title={a.aboutHeading} />
            <p className="mt-4 text-base leading-relaxed text-slate2">{a.aboutBody}</p>
          </section>
          <section>
            <SectionHeading title={a.missionHeading} />
            <p className="mt-4 text-base leading-relaxed text-slate2">{a.missionBody}</p>
          </section>
          <section>
            <SectionHeading title={a.visionHeading} />
            <p className="mt-4 text-base leading-relaxed text-slate2">{a.visionBody}</p>
          </section>
          <section>
            <SectionHeading title={a.philosophyHeading} />
            <p className="mt-4 text-base leading-relaxed text-slate2">{a.philosophyBody}</p>
          </section>
          <section>
            <SectionHeading title={a.qualityHeading} />
            <p className="mt-4 text-base leading-relaxed text-slate2">{a.qualityBody}</p>
          </section>
        </div>

        <aside>
          <div className="rounded-lg border border-navy-100 bg-white p-6 shadow-card">
            <Avatar initials="AH" size="h-16 w-16" />
            <h3 className="mt-4 font-serif text-lg font-semibold text-navy-900">{a.founderHeading}</h3>
            <p className="mt-3 text-sm leading-relaxed text-slate2">{a.founderQuote}</p>
            <p className="mt-4 text-sm font-semibold text-navy-900">{locale === "bn" ? "মোঃ আমির হামজা" : "Md. Amir Hamza"}</p>
            <p className="text-xs text-slate2">{a.founderTitle}</p>
            <p className="mt-2 text-xs italic text-slate2">{a.founderNote}</p>
          </div>
        </aside>
      </Container>
    </div>
  );
}

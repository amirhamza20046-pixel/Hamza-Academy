import Link from "next/link";
import PageHero from "@/components/PageHero";
import Container from "@/components/Container";
import { programs } from "@/data/programs";
import { getDictionary } from "@/lib/dictionaries";
import { localeHref } from "@/lib/paths";

export default function ProgramsView({ locale }) {
  const t = getDictionary(locale);
  const p = t.programs;

  return (
    <div>
      <PageHero kicker={p.kicker} title={p.title} description={p.desc} />
      <Container className="grid gap-6 py-14 sm:py-16 lg:grid-cols-2">
        {programs.map((program) => (
          <div key={program.slug} className="flex flex-col rounded-lg border border-navy-100 bg-white p-7 shadow-card">
            <h2 className="font-serif text-xl font-semibold text-navy-900">{program.name[locale]}</h2>
            <p className="mt-2 text-sm font-medium text-gold-600">{program.tagline[locale]}</p>
            <p className="mt-4 text-sm leading-relaxed text-slate2">{program.overview[locale]}</p>

            <div className="mt-5">
              <p className="text-xs font-semibold uppercase tracking-wide text-navy-500">{p.subjectsLabel}</p>
              <p className="mt-1 text-sm text-navy-800">{program.subjects.map((s) => s[locale]).join(", ")}</p>
            </div>

            <div className="mt-6 flex flex-col gap-3 sm:flex-row">
              <Link
                href={localeHref(locale, `/programs/${program.slug}`)}
                className="rounded-md bg-navy-800 px-5 py-2.5 text-center text-sm font-semibold text-white hover:bg-navy-900"
              >
                {p.viewDetailsBtn}
              </Link>
              <Link
                href={localeHref(locale, "/admission")}
                className="rounded-md border border-navy-300 px-5 py-2.5 text-center text-sm font-semibold text-navy-800 hover:border-navy-500"
              >
                {p.admissionBtn}
              </Link>
            </div>
          </div>
        ))}
      </Container>
    </div>
  );
}

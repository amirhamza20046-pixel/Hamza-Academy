// An original, simple flat illustration standing in for "a student joining
// an online class" — avoids stock photography while still being concrete
// and specific to the subject (not a generic abstract blob/gradient).
export default function HeroGraphic() {
  return (
    <svg viewBox="0 0 420 380" className="w-full max-w-md" role="img" aria-label="Illustration of a student attending an online class">
      <rect x="30" y="40" width="360" height="230" rx="14" fill="#0F2A4A" />
      <rect x="46" y="56" width="328" height="182" rx="6" fill="#F6F7F5" />

      <circle cx="210" cy="140" r="46" fill="#EAF0F6" />
      <circle cx="210" cy="122" r="20" fill="#0F2A4A" />
      <path d="M170 190C170 165 187 152 210 152C233 152 250 165 250 190" fill="#0F2A4A" />

      <rect x="66" y="76" width="70" height="46" rx="5" fill="#CBDAE9" />
      <rect x="284" y="76" width="70" height="46" rx="5" fill="#CBDAE9" />
      <rect x="66" y="196" width="70" height="34" rx="5" fill="#CBDAE9" />
      <rect x="284" y="196" width="70" height="34" rx="5" fill="#CBDAE9" />

      <rect x="150" y="270" width="120" height="14" rx="7" fill="#183C5C" />
      <rect x="176" y="292" width="68" height="10" rx="5" fill="#9FB9D2" />

      <g>
        <rect x="60" y="300" width="86" height="60" rx="6" fill="white" stroke="#CBDAE9" strokeWidth="2" />
        <rect x="72" y="312" width="62" height="6" rx="3" fill="#C9A24B" />
        <rect x="72" y="324" width="46" height="6" rx="3" fill="#9FB9D2" />
        <rect x="72" y="336" width="52" height="6" rx="3" fill="#9FB9D2" />
      </g>

      <g>
        <path d="M300 300L306 296L306 364L300 360Z" fill="#0F2A4A" />
        <rect x="306" y="296" width="60" height="68" rx="4" fill="#0F2A4A" />
        <rect x="312" y="304" width="48" height="6" rx="3" fill="#C9A24B" />
        <rect x="312" y="316" width="36" height="6" rx="3" fill="#6C93B6" />
        <rect x="312" y="328" width="40" height="6" rx="3" fill="#6C93B6" />
        <rect x="312" y="340" width="30" height="6" rx="3" fill="#6C93B6" />
      </g>
    </svg>
  );
}

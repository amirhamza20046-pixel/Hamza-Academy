// Original mark for Hamza Academy: an open book forming an "H", with a
// single gold nib/flame accent standing in for the "point" of achievement.
// Kept as inline SVG so there is no image asset to host or optimise.
export default function Mark({ className = "h-9 w-9" }) {
  return (
    <svg viewBox="0 0 48 48" className={className} fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
      <path d="M6 10C6 8.89543 6.89543 8 8 8H20C21.1046 8 22 8.89543 22 10V38C22 38 16 35 6 38V10Z" fill="#0F2A4A" />
      <path d="M42 10C42 8.89543 41.1046 8 40 8H28C26.8954 8 26 8.89543 26 10V38C26 38 32 35 42 38V10Z" fill="#0F2A4A" />
      <path d="M22 12C22 12 19 10.5 14 10.5" stroke="#F6F7F5" strokeWidth="1.4" strokeLinecap="round" />
      <path d="M22 18C22 18 19 16.5 14 16.5" stroke="#F6F7F5" strokeWidth="1.4" strokeLinecap="round" />
      <path d="M22 24C22 24 19 22.5 14 22.5" stroke="#F6F7F5" strokeWidth="1.4" strokeLinecap="round" />
      <path d="M26 12C26 12 29 10.5 34 10.5" stroke="#F6F7F5" strokeWidth="1.4" strokeLinecap="round" />
      <path d="M26 18C26 18 29 16.5 34 16.5" stroke="#F6F7F5" strokeWidth="1.4" strokeLinecap="round" />
      <path d="M26 24C26 24 29 22.5 34 22.5" stroke="#F6F7F5" strokeWidth="1.4" strokeLinecap="round" />
      <path d="M24 6L26.2 11.2L31.8 11.8L27.6 15.4L28.8 21L24 18L19.2 21L20.4 15.4L16.2 11.8L21.8 11.2L24 6Z" fill="#C9A24B" />
    </svg>
  );
}

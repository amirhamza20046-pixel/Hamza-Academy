// One small, specific icon per program — not a generic decorative glyph.
// "tone" controls the accent colour so it matches each program's card.

const paths = {
  // Open book — Class 1–5 Academic (foundational reading/writing)
  primary: (
    <>
      <path d="M12 7.5C10.3 6.4 8 6 5.5 6V17.5C8 17.5 10.3 17.9 12 19" />
      <path d="M12 7.5C13.7 6.4 16 6 18.5 6V17.5C16 17.5 13.7 17.9 12 19" />
      <path d="M12 7.5V19" />
    </>
  ),
  // Medal/ribbon — Class 5 Scholarship (merit & recognition)
  scholarship: (
    <>
      <circle cx="12" cy="9.5" r="4.5" />
      <path d="M9.2 13.3L7.5 20L12 17.5L16.5 20L14.8 13.3" />
    </>
  ),
  // Flask/beaker — Class 6–8 Academic (broader subjects incl. science)
  secondary: (
    <>
      <path d="M10 4H14" />
      <path d="M11 4V9.5L6.5 17.5C6 18.4 6.7 19.5 7.7 19.5H16.3C17.3 19.5 18 18.4 17.5 17.5L13 9.5V4" />
      <path d="M8.5 15H15.5" />
    </>
  ),
  // Shield with a star — Class 6 Cadet Admission (discipline & merit)
  cadet: (
    <>
      <path d="M12 4.5L18 6.8V11.5C18 15.3 15.4 18.3 12 19.5C8.6 18.3 6 15.3 6 11.5V6.8L12 4.5Z" />
      <path d="M12 9L12.9 10.9L15 11.2L13.5 12.6L13.9 14.7L12 13.6L10.1 14.7L10.5 12.6L9 11.2L11.1 10.9L12 9Z" fill="currentColor" stroke="none" />
    </>
  )
};

export default function ProgramIcon({ type, className = "h-6 w-6" }) {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.6"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      aria-hidden="true"
    >
      {paths[type] || paths.primary}
    </svg>
  );
}

"use client";

import { useState } from "react";
import { programs } from "@/data/programs";
import { site } from "@/data/site";
import { getDictionary } from "@/lib/dictionaries";

export default function AdmissionForm({ locale }) {
  const t = getDictionary(locale);
  const [form, setForm] = useState({
    program: programs[0]?.shortName[locale] || "",
    studentName: "",
    studentClass: "",
    guardianName: "",
    mobile: "",
    message: ""
  });
  const [submitted, setSubmitted] = useState(false);

  function handleChange(e) {
    const { name, value } = e.target;
    setForm((f) => ({ ...f, [name]: value }));
  }

  function handleSubmit(e) {
    e.preventDefault();
    setSubmitted(true);
    const subject = encodeURIComponent(`Admission Enquiry — ${form.program}`);
    const body = `Admission Enquiry — Hamza Academy%0D%0A%0D%0AProgram: ${form.program}%0D%0AStudent Name: ${form.studentName}%0D%0AClass: ${form.studentClass}%0D%0AGuardian Name: ${form.guardianName}%0D%0AMobile Number: ${form.mobile}%0D%0AMessage: ${form.message}`;
    window.location.href = `mailto:${site.email}?subject=${subject}&body=${body}`;
  }

  return (
    <form onSubmit={handleSubmit} className="rounded-lg border border-navy-100 bg-white p-6 shadow-card sm:p-8">
      <div className="grid gap-5 sm:grid-cols-2">
        <Field label={t.admission.programLabel} htmlFor="program">
          <select
            id="program"
            name="program"
            value={form.program}
            onChange={handleChange}
            className="w-full rounded-md border border-navy-200 bg-white px-3 py-2.5 text-sm text-navy-900 focus:border-navy-500 focus:outline-none focus:ring-2 focus:ring-navy-100"
          >
            {programs.map((p) => (
              <option key={p.slug} value={p.shortName[locale]}>{p.shortName[locale]}</option>
            ))}
          </select>
        </Field>

        <Field label={t.admission.classLabel} htmlFor="studentClass">
          <input
            id="studentClass"
            name="studentClass"
            required
            value={form.studentClass}
            onChange={handleChange}
            placeholder={t.admission.classPlaceholder}
            className="w-full rounded-md border border-navy-200 px-3 py-2.5 text-sm focus:border-navy-500 focus:outline-none focus:ring-2 focus:ring-navy-100"
          />
        </Field>

        <Field label={t.admission.studentNameLabel} htmlFor="studentName">
          <input
            id="studentName"
            name="studentName"
            required
            value={form.studentName}
            onChange={handleChange}
            className="w-full rounded-md border border-navy-200 px-3 py-2.5 text-sm focus:border-navy-500 focus:outline-none focus:ring-2 focus:ring-navy-100"
          />
        </Field>

        <Field label={t.admission.guardianNameLabel} htmlFor="guardianName">
          <input
            id="guardianName"
            name="guardianName"
            required
            value={form.guardianName}
            onChange={handleChange}
            className="w-full rounded-md border border-navy-200 px-3 py-2.5 text-sm focus:border-navy-500 focus:outline-none focus:ring-2 focus:ring-navy-100"
          />
        </Field>

        <Field label={t.admission.mobileLabel} htmlFor="mobile">
          <input
            id="mobile"
            name="mobile"
            type="tel"
            required
            value={form.mobile}
            onChange={handleChange}
            placeholder="01XXXXXXXXX"
            className="w-full rounded-md border border-navy-200 px-3 py-2.5 text-sm focus:border-navy-500 focus:outline-none focus:ring-2 focus:ring-navy-100"
          />
        </Field>
      </div>

      <Field label={t.admission.messageLabel} htmlFor="message" className="mt-5">
        <textarea
          id="message"
          name="message"
          rows={4}
          value={form.message}
          onChange={handleChange}
          placeholder={t.admission.messagePlaceholder}
          className="w-full rounded-md border border-navy-200 px-3 py-2.5 text-sm focus:border-navy-500 focus:outline-none focus:ring-2 focus:ring-navy-100"
        />
      </Field>

      <div className="mt-6 flex flex-col gap-3 sm:flex-row sm:items-center">
        <button
          type="submit"
          className="rounded-md bg-navy-800 px-6 py-3 text-sm font-semibold text-white transition-colors hover:bg-navy-900"
        >
          {t.admission.submitBtn}
        </button>
        <p className="text-xs text-slate2">{t.admission.submitHint(site.email, site.phone)}</p>
      </div>

      {submitted && (
        <p className="mt-4 text-sm font-medium text-navy-700" role="status">
          {t.admission.submittedMsg}
        </p>
      )}
    </form>
  );
}

function Field({ label, htmlFor, children, className = "" }) {
  return (
    <div className={className}>
      <label htmlFor={htmlFor} className="mb-1.5 block text-sm font-medium text-navy-800">
        {label}
      </label>
      {children}
    </div>
  );
}

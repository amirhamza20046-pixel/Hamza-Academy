import Avatar from "./Avatar";

export default function TeacherCard({ teacher, locale }) {
  return (
    <div className="flex flex-col items-center rounded-lg border border-navy-100 bg-white p-6 text-center shadow-card">
      <Avatar initials={teacher.initials} />
      <h3 className="mt-4 font-serif text-base font-semibold text-navy-900">{teacher.name[locale]}</h3>
      <p className="mt-0.5 text-sm font-medium text-gold-600">{teacher.designation[locale]}</p>
      <p className="text-xs text-slate2">{teacher.subject[locale]}</p>
      <p className="mt-3 text-sm leading-relaxed text-slate2">{teacher.bio[locale]}</p>
    </div>
  );
}

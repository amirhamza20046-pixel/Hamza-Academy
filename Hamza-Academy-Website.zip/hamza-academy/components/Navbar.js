"use client";

import { useState } from "react";
import Link from "next/link";
import Container from "./Container";
import Mark from "./Mark";
import LanguageSwitcher from "./LanguageSwitcher";
import { site, mainNavRoutes } from "@/data/site";
import { getDictionary } from "@/lib/dictionaries";
import { localeHref } from "@/lib/paths";

export default function Navbar({ locale }) {
  const [open, setOpen] = useState(false);
  const t = getDictionary(locale);
  const brandName = locale === "bn" ? site.nameBn : site.name;

  return (
    <header className="sticky top-0 z-50 border-b border-navy-100 bg-paper/95 backdrop-blur">
      <Container className="flex h-16 items-center justify-between sm:h-20">
        <Link href={localeHref(locale, "/")} className="flex items-center gap-3" onClick={() => setOpen(false)}>
          <Mark className="h-9 w-9 sm:h-10 sm:w-10" />
          <span className="leading-tight">
            <span className="block font-serif text-lg font-bold tracking-tight text-navy-900 sm:text-xl">
              {brandName}
            </span>
            <span className="hidden text-[11px] font-medium tracking-wide text-gold-600 sm:block">
              {t.home.heroEyebrow}
            </span>
          </span>
        </Link>

        <nav className="hidden items-center gap-1 xl:flex">
          {mainNavRoutes.map((item) => (
            <Link
              key={item.href}
              href={localeHref(locale, item.href)}
              className="rounded-md px-3 py-2 text-sm font-medium text-navy-700 transition-colors hover:bg-navy-50 hover:text-navy-900"
            >
              {t.nav[item.key]}
            </Link>
          ))}
        </nav>

        <div className="hidden items-center gap-3 xl:flex">
          <LanguageSwitcher locale={locale} />
          <Link
            href={localeHref(locale, "/admission")}
            className="rounded-md bg-navy-800 px-4 py-2.5 text-sm font-semibold text-white shadow-sm transition-colors hover:bg-navy-900"
          >
            {t.common.admissionInfo}
          </Link>
        </div>

        <div className="flex items-center gap-2 xl:hidden">
          <LanguageSwitcher locale={locale} />
          <button
            type="button"
            aria-label={open ? "Close menu" : "Open menu"}
            aria-expanded={open}
            onClick={() => setOpen((v) => !v)}
            className="flex h-10 w-10 items-center justify-center rounded-md border border-navy-200 text-navy-800"
          >
            {open ? (
              <svg width="20" height="20" viewBox="0 0 20 20" fill="none" aria-hidden="true">
                <path d="M4 4L16 16M16 4L4 16" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" />
              </svg>
            ) : (
              <svg width="20" height="20" viewBox="0 0 20 20" fill="none" aria-hidden="true">
                <path d="M3 5H17M3 10H17M3 15H17" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" />
              </svg>
            )}
          </button>
        </div>
      </Container>

      {open && (
        <div className="border-t border-navy-100 bg-paper xl:hidden">
          <Container className="flex flex-col py-3">
            {mainNavRoutes.map((item) => (
              <Link
                key={item.href}
                href={localeHref(locale, item.href)}
                onClick={() => setOpen(false)}
                className="rounded-md px-3 py-3 text-base font-medium text-navy-800 hover:bg-navy-50"
              >
                {t.nav[item.key]}
              </Link>
            ))}
            <Link
              href={localeHref(locale, "/admission")}
              onClick={() => setOpen(false)}
              className="mt-2 rounded-md bg-navy-800 px-4 py-3 text-center text-base font-semibold text-white"
            >
              {t.common.admissionInfo}
            </Link>
          </Container>
        </div>
      )}
    </header>
  );
}

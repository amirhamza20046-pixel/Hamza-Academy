"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { splitLocaleFromPath } from "@/lib/paths";

export default function LanguageSwitcher({ locale, className = "" }) {
  const pathname = usePathname();
  const { path } = splitLocaleFromPath(pathname || "/");
  const targetLocale = locale === "bn" ? "en" : "bn";
  const targetHref = targetLocale === "en" ? (path === "/" ? "/en" : `/en${path}`) : path;
  const label = locale === "bn" ? "English" : "বাংলা";

  return (
    <Link
      href={targetHref}
      lang={targetLocale}
      className={`inline-flex items-center gap-1.5 rounded-md border border-navy-200 px-3 py-1.5 text-xs font-semibold text-navy-700 transition-colors hover:border-navy-400 hover:text-navy-900 ${className}`}
    >
      <svg width="13" height="13" viewBox="0 0 20 20" fill="none" aria-hidden="true">
        <circle cx="10" cy="10" r="7.5" stroke="currentColor" strokeWidth="1.4" />
        <path d="M2.5 10H17.5" stroke="currentColor" strokeWidth="1.4" />
        <path d="M10 2.5C12 4.7 13 7.2 13 10C13 12.8 12 15.3 10 17.5C8 15.3 7 12.8 7 10C7 7.2 8 4.7 10 2.5Z" stroke="currentColor" strokeWidth="1.4" />
      </svg>
      {label}
    </Link>
  );
}

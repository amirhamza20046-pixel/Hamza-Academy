import Link from "next/link";
import Container from "./Container";
import Mark from "./Mark";
import { site, mainNavRoutes } from "@/data/site";
import { getDictionary } from "@/lib/dictionaries";
import { localeHref } from "@/lib/paths";

export default function Footer({ locale }) {
  const t = getDictionary(locale);
  const brandName = locale === "bn" ? site.nameBn : site.name;
  const address = locale === "bn" ? site.addressBn : site.address;
  const half = Math.ceil(mainNavRoutes.length / 2);

  return (
    <footer className="bg-navy-950 text-navy-100">
      <Container className="grid gap-10 py-14 sm:grid-cols-2 lg:grid-cols-4">
        <div>
          <div className="flex items-center gap-2.5">
            <Mark className="h-9 w-9" />
            <span className="font-serif text-xl font-bold text-white">{brandName}</span>
          </div>
          <p className="mt-4 max-w-xs text-sm leading-relaxed text-navy-200">{t.home.heroDesc}</p>
          <div className="mt-5 flex gap-3">
            <SocialIcon href={site.social.facebook} label="Facebook">
              <path d="M13.5 9H16V6H13.5C11.567 6 10 7.567 10 9.5V11H8V14H10V20H13V14H15.5L16 11H13V9.5C13 9.224 13.224 9 13.5 9Z" />
            </SocialIcon>
            <SocialIcon href={site.social.instagram} label="Instagram">
              <rect x="5" y="5" width="14" height="14" rx="4" fill="none" stroke="currentColor" strokeWidth="1.6" />
              <circle cx="12" cy="12" r="3.2" fill="none" stroke="currentColor" strokeWidth="1.6" />
              <circle cx="16.2" cy="7.8" r="0.9" />
            </SocialIcon>
            <SocialIcon href={site.social.youtube} label="YouTube">
              <rect x="4" y="7" width="16" height="10" rx="3" fill="none" stroke="currentColor" strokeWidth="1.6" />
              <path d="M10.5 10.2L14.5 12L10.5 13.8V10.2Z" />
            </SocialIcon>
          </div>
        </div>

        <div>
          <h3 className="font-serif text-base font-semibold text-white">{t.footer.exploreHeading}</h3>
          <ul className="mt-4 space-y-2.5 text-sm">
            {mainNavRoutes.slice(0, half).map((item) => (
              <li key={item.href}>
                <Link href={localeHref(locale, item.href)} className="text-navy-200 transition-colors hover:text-gold-300">
                  {t.nav[item.key]}
                </Link>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h3 className="font-serif text-base font-semibold text-white">{t.footer.moreHeading}</h3>
          <ul className="mt-4 space-y-2.5 text-sm">
            {mainNavRoutes.slice(half).map((item) => (
              <li key={item.href}>
                <Link href={localeHref(locale, item.href)} className="text-navy-200 transition-colors hover:text-gold-300">
                  {t.nav[item.key]}
                </Link>
              </li>
            ))}
            <li>
              <Link href={localeHref(locale, "/admission")} className="text-navy-200 transition-colors hover:text-gold-300">
                {t.nav.admission}
              </Link>
            </li>
          </ul>
        </div>

        <div>
          <h3 className="font-serif text-base font-semibold text-white">{t.footer.contactHeading}</h3>
          <ul className="mt-4 space-y-2.5 text-sm text-navy-200">
            <li>{address}</li>
            <li>
              <a href={`tel:${site.phone}`} className="hover:text-gold-300">{site.phone}</a>
            </li>
            <li>
              <a href={`mailto:${site.email}`} className="hover:text-gold-300">{site.email}</a>
            </li>
          </ul>
        </div>
      </Container>

      <div className="border-t border-navy-800">
        <Container className="flex flex-col items-center justify-between gap-2 py-5 text-xs text-navy-300 sm:flex-row">
          <p>© {new Date().getFullYear()} {brandName}. {t.footer.rightsReserved}</p>
          <p>{t.footer.footerTag}</p>
        </Container>
      </div>
    </footer>
  );
}

function SocialIcon({ href, label, children }) {
  return (
    <a
      href={href}
      target="_blank"
      rel="noopener noreferrer"
      aria-label={label}
      className="flex h-9 w-9 items-center justify-center rounded-full border border-navy-700 text-navy-100 transition-colors hover:border-gold-400 hover:text-gold-300"
    >
      <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
        {children}
      </svg>
    </a>
  );
}

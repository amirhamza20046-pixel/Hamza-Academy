export default function TestimonialCard({ testimonial, locale }) {
  return (
    <figure className="flex h-full flex-col justify-between rounded-lg border border-navy-100 bg-white p-6 shadow-card">
      <blockquote className="text-sm leading-relaxed text-navy-800">“{testimonial.quote[locale]}”</blockquote>
      <figcaption className="mt-5 border-t border-navy-100 pt-3">
        <p className="text-sm font-semibold text-navy-900">{testimonial.author[locale]}</p>
        <p className="text-xs text-slate2">{testimonial.context[locale]}</p>
      </figcaption>
    </figure>
  );
}

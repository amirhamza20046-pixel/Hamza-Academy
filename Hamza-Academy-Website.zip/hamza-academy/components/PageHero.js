import Container from "./Container";
import DotGrid from "./DotGrid";

export default function PageHero({ kicker, title, description }) {
  return (
    <div className="relative overflow-hidden border-b border-navy-100 bg-navy-900">
      <DotGrid className="right-0 top-0 hidden h-72 w-72 text-white opacity-[0.06] sm:block" />
      <Container className="relative py-14 sm:py-16">
        {kicker && (
          <div className="flex items-center gap-2">
            <span className="h-[3px] w-6 rounded-full bg-gold-400" aria-hidden="true" />
            <p className="text-sm font-semibold tracking-wide text-gold-400">{kicker}</p>
          </div>
        )}
        <h1 className="mt-3 max-w-2xl font-serif text-3xl font-bold text-white sm:text-4xl">{title}</h1>
        {description && <p className="mt-3 max-w-xl text-base leading-relaxed text-navy-200">{description}</p>}
      </Container>
    </div>
  );
}

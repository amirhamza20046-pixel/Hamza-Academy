import { formatDate } from "@/lib/dictionaries";

const typeStyles = {
  Admission: "bg-gold-50 text-gold-700 border-gold-200",
  Batch: "bg-navy-50 text-navy-700 border-navy-200",
  Exam: "bg-navy-50 text-navy-700 border-navy-200",
  Holiday: "bg-paper text-slate2 border-navy-100",
  General: "bg-paper text-slate2 border-navy-100"
};

export default function NoticeCard({ notice, locale }) {
  const tagClass = typeStyles[notice.type] || typeStyles.General;
  return (
    <div className="flex flex-col gap-2 rounded-lg border border-navy-100 bg-white p-5 shadow-card sm:flex-row sm:items-start sm:justify-between sm:gap-6">
      <div>
        <div className="flex flex-wrap items-center gap-2">
          <span className={`rounded-full border px-2.5 py-0.5 text-xs font-semibold ${tagClass}`}>{notice.typeLabel[locale]}</span>
          <span className="text-xs text-slate2">{formatDate(notice.date, locale)}</span>
        </div>
        <h3 className="mt-2 font-serif text-base font-semibold text-navy-900">{notice.title[locale]}</h3>
        <p className="mt-1 text-sm leading-relaxed text-slate2">{notice.details[locale]}</p>
      </div>
    </div>
  );
}

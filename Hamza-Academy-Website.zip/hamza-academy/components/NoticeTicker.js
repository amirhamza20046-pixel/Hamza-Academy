import Link from "next/link";
import { notices } from "@/data/notices";
import { getDictionary } from "@/lib/dictionaries";
import { localeHref } from "@/lib/paths";

// Pure CSS marquee — no JS animation library, so it stays fast and cheap
// to run. Content is duplicated once so the loop is seamless; animation
// pauses automatically for people who prefer reduced motion (see globals.css).
export default function NoticeTicker({ locale }) {
  const t = getDictionary(locale);
  const items = notices.slice(0, 5);
  if (items.length === 0) return null;

  const track = (
    <>
      {items.map((n, i) => (
        <span key={`${n.id}-${i}`} className="mx-6 inline-flex items-center gap-2 text-sm text-navy-100">
          <span className="h-1.5 w-1.5 shrink-0 rounded-full bg-gold-400" aria-hidden="true" />
          {n.title[locale]}
        </span>
      ))}
    </>
  );

  return (
    <div className="flex items-center gap-3 bg-navy-950 py-2 text-navy-100">
      <Link
        href={localeHref(locale, "/notices")}
        className="hidden shrink-0 items-center gap-1.5 border-r border-navy-800 pl-5 pr-4 text-xs font-semibold uppercase tracking-wide text-gold-400 sm:flex"
      >
        {t.common.notice}
      </Link>
      <div className="ticker-mask flex-1 overflow-hidden">
        <div className="ticker-track flex w-max whitespace-nowrap">
          {track}
          {track}
        </div>
      </div>
    </div>
  );
}

export default function SectionHeading({ eyebrow, title, description, align = "left" }) {
  const alignClass = align === "center" ? "text-center items-center mx-auto" : "text-left items-start";
  return (
    <div className={`flex max-w-2xl flex-col gap-3 ${alignClass}`}>
      {eyebrow && (
        <div className={`flex items-center gap-2 ${align === "center" ? "justify-center" : ""}`}>
          <span className="h-[3px] w-6 rounded-full bg-gold-500" aria-hidden="true" />
          <p className="text-sm font-semibold tracking-wide text-gold-600">{eyebrow}</p>
        </div>
      )}
      <h2 className="font-serif text-2xl font-semibold text-navy-900 sm:text-3xl">{title}</h2>
      {description && <p className="text-base leading-relaxed text-slate2">{description}</p>}
    </div>
  );
}

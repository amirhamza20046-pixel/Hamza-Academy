export default function Avatar({ initials, size = "h-20 w-20" }) {
  return (
    <div
      className={`flex ${size} shrink-0 items-center justify-center rounded-full bg-navy-100 font-serif text-lg font-semibold text-navy-700`}
      aria-hidden="true"
    >
      {initials}
    </div>
  );
}

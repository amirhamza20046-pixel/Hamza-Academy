import { NextResponse } from "next/server";

// The only job of this middleware is to tell the root layout which
// language is being requested (via a request header) so it can set the
// correct <html lang="..."> attribute — Bangla ("bn") is the default for
// every path that doesn't start with /en.
export function middleware(request) {
  const { pathname } = request.nextUrl;
  const locale = pathname === "/en" || pathname.startsWith("/en/") ? "en" : "bn";

  const requestHeaders = new Headers(request.headers);
  requestHeaders.set("x-locale", locale);

  return NextResponse.next({ request: { headers: requestHeaders } });
}

export const config = {
  matcher: ["/((?!_next|favicon.svg|robots.txt|sitemap.xml).*)"]
};

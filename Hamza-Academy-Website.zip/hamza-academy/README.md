# Hamza Academy — Website (Version 1)

A modern, fast, low-cost website for Hamza Academy's online academic and admission
coaching. Built with **Next.js** (App Router) and **Tailwind CSS**, using static
data files instead of a database — no backend, no login system, no payment
gateway. Version 1 is intentionally simple so it stays cheap to host and easy
to maintain; see "Planned future features" below for what's structured in
but not yet built.

## 1. Tech stack (and why)

| Piece            | Choice                | Why |
|-------------------|-----------------------|-----|
| Framework         | Next.js 14 (App Router) | Fast, SEO-friendly, huge community, free hosting tier on Vercel |
| Styling           | Tailwind CSS           | No custom CSS to maintain, small final CSS size, fast to edit |
| Content           | Local JS data files (`/data`) | No database cost, content changes are just text edits |
| Forms             | Client-side, `mailto:` links | Zero backend cost for v1 — see "Forms" below for upgrade path |
| Hosting           | Vercel (or Netlify) free tier | $0/month for this traffic level, deploys from Git automatically |

This avoids any monthly database or server cost while still being a real,
production-quality React/Next.js site — not a page-builder template.

## 2. Folder structure

```
hamza-academy/
├── middleware.js            # Detects bn/en from the URL for <html lang>
├── app/
│   ├── layout.js            # Root shell only: fonts + <html lang>
│   ├── globals.css
│   ├── sitemap.js           # Auto-generated sitemap.xml (both languages)
│   ├── robots.js            # Auto-generated robots.txt
│   ├── (bn)/                # Bangla routes — served at "/", "/programs", etc.
│   │   ├── layout.js        # Navbar/Footer/Ticker in Bangla + SEO metadata
│   │   ├── page.js          # Home
│   │   ├── about/page.js
│   │   ├── programs/page.js
│   │   ├── programs/[slug]/page.js
│   │   ├── routine/page.js
│   │   ├── notices/page.js
│   │   ├── online-classes/page.js
│   │   ├── materials/page.js
│   │   ├── results/page.js
│   │   ├── teachers/page.js
│   │   ├── gallery/page.js
│   │   ├── contact/page.js
│   │   └── admission/page.js
│   └── en/                  # English routes — mirrors (bn) at "/en/..."
│       └── ...same file list as (bn), each rendering the same view
│           component with locale="en"
├── components/
│   ├── views/                # One shared page layout per route (bilingual)
│   │   ├── HomeView.js, AboutView.js, ProgramsView.js, ...
│   ├── Navbar.js, Footer.js, NoticeTicker.js   # locale-aware chrome
│   ├── LanguageSwitcher.js
│   └── ...cards, forms, icons (all locale-aware)
├── lib/
│   ├── dictionaries.js       # All interface text, in bn + en
│   └── paths.js              # Helpers to build locale-correct links
├── data/                     # <-- EDIT THESE FILES TO CHANGE CONTENT
│   ├── site.js               # Academy name, phone, email, social links, nav
│   ├── programs.js           # The 4 programs — every field is { bn, en }
│   ├── teachers.js
│   ├── notices.js
│   ├── routine.js
│   ├── results.js
│   ├── materials.js
│   ├── testimonials.js
│   └── gallery.js
└── public/                   # Static files (favicon, future real photos)
```

Note the `(bn)` folder name: the parentheses make it a Next.js "route
group" — it organizes files without adding a `/bn` segment to the URL,
which is how Bangla stays at the clean, unprefixed URLs while still having
its own layout file.

## 3. Bilingual content (Bangla + English)

The site is fully bilingual, with **Bangla as the default/primary language**:

- Bangla lives at the normal URLs — `/`, `/programs`, `/contact`, etc.
- English lives at the same paths under `/en` — `/en`, `/en/programs`, `/en/contact`.
- A language switcher in the header (and the URL itself) lets visitors flip
  between the two; each page remembers its own path when switching, so
  `/en/programs` ↔ `/programs`, `/en/contact` ↔ `/contact`, and so on.
- `<html lang="bn">` / `<html lang="en">` is set correctly per page (via
  `middleware.js`), and every page declares `hreflang` alternates for SEO —
  no extra i18n library, just Next.js's built-in routing and metadata APIs.

**How the content is organized (no coding needed to edit text):**
- `lib/dictionaries.js` — every piece of *interface* text (buttons, nav
  labels, page titles/descriptions, form labels) in both languages, one
  object per language, one key per string.
- `data/*.js` — every piece of *content* (programs, notices, routine,
  results, teachers, materials, testimonials) is bilingual: each field is
  `{ bn: "...", en: "..." }`. Edit both keys to keep the languages in sync.
- `components/views/*.js` — one shared "view" component per page (e.g.
  `HomeView.js`), used by both the Bangla and the English route file. This
  means the page layout is written once; only the words differ per
  language — so there's no duplicate markup to keep in sync.

**Typography:** Bangla body text and headings use the **Hind Siliguri** and
**Noto Serif Bengali** Google Fonts (both loaded for free via
`next/font/google`, no extra dependency or paid font license), chosen for
clear rendering of Bangla conjuncts at both small and heading sizes. English
pages use Inter (body) and Lora (headings) as before. The font actually
used for headings switches automatically per language via a CSS variable —
see `app/globals.css` and `app/layout.js` if you ever want to swap fonts.

**Adding a new page or updating both languages at once:** add the new
strings to *both* the `bn` and `en` objects in `lib/dictionaries.js` (or
both `bn`/`en` keys in the relevant `data/*.js` file), then the same view
component will pick up the right language automatically — you don't need
to touch `app/(bn)/...` or `app/en/...` for content changes, only for
adding a brand-new route.

## 4. Editing content (no coding needed for most changes)

Everything a non-developer needs to change day-to-day lives in `/data/*.js`
as plain objects/arrays. For example, to add a new notice, open
`data/notices.js` and add a new entry at the top of the array following the
same shape as the existing ones. The same pattern applies to the routine,
results, study materials, teachers and testimonials.

## 5. Forms (admission enquiry & contact)

Per the brief, v1 avoids an expensive backend. Both forms currently open the
visitor's email app with a pre-filled message (a `mailto:` link) — no server,
no monthly cost. When you're ready, this can be swapped for:
- A free **Google Form** embed, or
- A free tier of **Formspree**/**Web3Forms**, or
- A simple serverless function (Vercel/Netlify function) if you later want
  submissions saved somewhere.

Update `site.email` and `site.phone` in `data/site.js` — the forms use those
automatically.

## 6. Images

The site currently ships with **no external photos** — the logo, hero
illustration and gallery are original inline SVGs / labelled placeholders, so
there's nothing to license or slow the site down. To add real photos:
1. Put image files in `/public/images/`.
2. Reference them with Next.js's `<Image>` component (see Next.js docs) or a
   plain `<img>` tag, pointing at `/images/your-file.jpg`.
3. Update `data/teachers.js` / `data/gallery.js` with the new paths.

## 7. Running the project locally

You'll need [Node.js](https://nodejs.org) 18 or newer installed.

```bash
cd hamza-academy
npm install
npm run dev
```

Then open **http://localhost:3000** in your browser. The page auto-reloads
as you edit files.

To create an optimized production build (used automatically by most hosts):

```bash
npm run build
npm run start
```

## 8. Deploying on low-cost hosting

**Recommended: Vercel** (made by the creators of Next.js — free tier is
enough for this site).

1. Push this project to a GitHub repository.
2. Go to [vercel.com](https://vercel.com), sign up, click **"New Project"**,
   and import the GitHub repo.
3. Leave the default settings (Vercel auto-detects Next.js) and click
   **Deploy**.
4. You'll get a free `*.vercel.app` URL immediately.

**Adding your own domain later:**
1. Buy a domain (e.g. from Namecheap or a local Bangladeshi registrar).
2. In your Vercel project, go to **Settings → Domains**, add the domain, and
   follow the DNS instructions shown (usually just adding one or two DNS
   records at your domain registrar).

**Alternative: Netlify** works the same way — import the Git repo, it
auto-detects Next.js, and deploys on a free tier.

## 9. Planned future features (structured for, not built in v1)

The codebase intentionally keeps these out for now but doesn't block them:
- Student login & digital ID
- Attendance tracking
- Online exams
- Progress reports & guardian dashboard
- Offline branch information / physical classroom management

When you're ready to add any of these, they'd sit alongside the current
`/app` routes as new sections (e.g. `/app/portal/...`) with their own
authentication — the current site's content and design won't need to change.

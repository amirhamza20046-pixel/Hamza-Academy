import { headers } from "next/headers";
import { Inter, Lora, Hind_Siliguri, Noto_Serif_Bengali } from "next/font/google";
import "./globals.css";

const inter = Inter({ subsets: ["latin"], variable: "--font-inter", display: "swap" });
const lora = Lora({ subsets: ["latin"], variable: "--font-lora", display: "swap" });
const hindSiliguri = Hind_Siliguri({
  subsets: ["bengali"],
  weight: ["400", "500", "600", "700"],
  variable: "--font-hind-siliguri",
  display: "swap"
});
const notoSerifBengali = Noto_Serif_Bengali({
  subsets: ["bengali"],
  weight: ["500", "600", "700"],
  variable: "--font-noto-serif-bengali",
  display: "swap"
});

export const metadata = {
  metadataBase: new URL("https://www.hamzaacademy.com"),
  icons: { icon: "/favicon.svg" }
};

// The root layout only sets up fonts/shell and the correct <html lang>.
// Locale-specific metadata, header, footer and the notice ticker are added
// per language by app/(bn)/layout.js (default, unprefixed URLs) and
// app/en/layout.js. The current locale comes from middleware.js, which
// reads the URL once per request so this stays a plain Server Component.
export default function RootLayout({ children }) {
  const locale = headers().get("x-locale") === "en" ? "en" : "bn";
  const fontClass = locale === "bn" ? "font-bangla" : "font-sans";
  return (
    <html
      lang={locale}
      data-locale={locale}
      className={`${inter.variable} ${lora.variable} ${hindSiliguri.variable} ${notoSerifBengali.variable}`}
    >
      <body className={`flex min-h-screen flex-col antialiased ${fontClass}`}>{children}</body>
    </html>
  );
}

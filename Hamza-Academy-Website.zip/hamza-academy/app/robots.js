export default function robots() {
  return {
    rules: {
      userAgent: "*",
      allow: "/"
    },
    sitemap: "https://www.hamzaacademy.com/sitemap.xml"
  };
}

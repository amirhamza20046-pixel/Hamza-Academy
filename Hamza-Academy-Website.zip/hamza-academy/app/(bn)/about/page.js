import AboutView from "@/components/views/AboutView";
import { getDictionary } from "@/lib/dictionaries";

export function generateMetadata() {
  const t = getDictionary("bn");
  return { title: t.about.title, description: t.about.desc };
}

export default function Page() {
  return <AboutView locale="bn" />;
}

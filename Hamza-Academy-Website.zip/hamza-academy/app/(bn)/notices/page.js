import NoticesView from "@/components/views/NoticesView";
import { getDictionary } from "@/lib/dictionaries";

export function generateMetadata() {
  const t = getDictionary("bn");
  return { title: t.notices.title, description: t.notices.desc };
}

export default function Page() {
  return <NoticesView locale="bn" />;
}

import GalleryView from "@/components/views/GalleryView";
import { getDictionary } from "@/lib/dictionaries";

export function generateMetadata() {
  const t = getDictionary("bn");
  return { title: t.gallery.title, description: t.gallery.desc };
}

export default function Page() {
  return <GalleryView locale="bn" />;
}

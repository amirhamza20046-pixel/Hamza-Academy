import AdmissionView from "@/components/views/AdmissionView";
import { getDictionary } from "@/lib/dictionaries";

export function generateMetadata() {
  const t = getDictionary("bn");
  return { title: t.admission.title, description: t.admission.desc };
}

export default function Page() {
  return <AdmissionView locale="bn" />;
}

import MaterialsView from "@/components/views/MaterialsView";
import { getDictionary } from "@/lib/dictionaries";

export function generateMetadata() {
  const t = getDictionary("bn");
  return { title: t.materials.title, description: t.materials.desc };
}

export default function Page() {
  return <MaterialsView locale="bn" />;
}

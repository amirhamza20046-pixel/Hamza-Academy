import RoutineView from "@/components/views/RoutineView";
import { getDictionary } from "@/lib/dictionaries";

export function generateMetadata() {
  const t = getDictionary("bn");
  return { title: t.routine.title, description: t.routine.desc };
}

export default function Page() {
  return <RoutineView locale="bn" />;
}

import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import NoticeTicker from "@/components/NoticeTicker";
import { getDictionary } from "@/lib/dictionaries";

export function generateMetadata() {
  const t = getDictionary("bn");
  return {
    title: {
      default: t.meta.homeTitle,
      template: `%s — ${t.meta.titleSuffix}`
    },
    description: t.meta.description,
    alternates: {
      canonical: "https://www.hamzaacademy.com/",
      languages: {
        bn: "https://www.hamzaacademy.com/",
        en: "https://www.hamzaacademy.com/en"
      }
    },
    openGraph: {
      title: t.meta.homeTitle,
      description: t.meta.description,
      siteName: t.meta.titleSuffix,
      type: "website",
      locale: "bn_BD"
    }
  };
}

export default function BnLayout({ children }) {
  return (
    <>
      <NoticeTicker locale="bn" />
      <Navbar locale="bn" />
      <main className="flex-1">{children}</main>
      <Footer locale="bn" />
    </>
  );
}

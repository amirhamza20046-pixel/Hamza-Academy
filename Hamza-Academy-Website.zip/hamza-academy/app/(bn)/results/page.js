import ResultsView from "@/components/views/ResultsView";
import { getDictionary } from "@/lib/dictionaries";

export function generateMetadata() {
  const t = getDictionary("bn");
  return { title: t.results.title, description: t.results.desc };
}

export default function Page() {
  return <ResultsView locale="bn" />;
}

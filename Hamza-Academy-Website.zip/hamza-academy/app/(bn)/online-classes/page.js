import OnlineClassesView from "@/components/views/OnlineClassesView";
import { getDictionary } from "@/lib/dictionaries";

export function generateMetadata() {
  const t = getDictionary("bn");
  return { title: t.onlineClasses.title, description: t.onlineClasses.desc };
}

export default function Page() {
  return <OnlineClassesView locale="bn" />;
}

import NotFoundView from "@/components/views/NotFoundView";

export default function NotFound() {
  return <NotFoundView locale="en" />;
}

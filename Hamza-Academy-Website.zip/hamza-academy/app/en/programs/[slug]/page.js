import { notFound } from "next/navigation";
import ProgramDetailView from "@/components/views/ProgramDetailView";
import { programs, getProgramBySlug } from "@/data/programs";

export function generateStaticParams() {
  return programs.map((p) => ({ slug: p.slug }));
}

export function generateMetadata({ params }) {
  const program = getProgramBySlug(params.slug);
  if (!program) return {};
  return { title: program.name.en, description: program.overview.en };
}

export default function Page({ params }) {
  const program = getProgramBySlug(params.slug);
  if (!program) return notFound();
  return <ProgramDetailView locale="en" program={program} />;
}

import ProgramsView from "@/components/views/ProgramsView";
import { getDictionary } from "@/lib/dictionaries";

export function generateMetadata() {
  const t = getDictionary("en");
  return { title: t.programs.title, description: t.programs.desc };
}

export default function Page() {
  return <ProgramsView locale="en" />;
}

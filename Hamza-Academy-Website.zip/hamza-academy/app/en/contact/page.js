import ContactView from "@/components/views/ContactView";
import { getDictionary } from "@/lib/dictionaries";

export function generateMetadata() {
  const t = getDictionary("en");
  return { title: t.contact.title, description: t.contact.desc };
}

export default function Page() {
  return <ContactView locale="en" />;
}

import TeachersView from "@/components/views/TeachersView";
import { getDictionary } from "@/lib/dictionaries";

export function generateMetadata() {
  const t = getDictionary("en");
  return { title: t.teachers.title, description: t.teachers.desc };
}

export default function Page() {
  return <TeachersView locale="en" />;
}

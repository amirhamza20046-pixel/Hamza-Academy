import { programs } from "@/data/programs";
import { mainNavRoutes } from "@/data/site";

export default function sitemap() {
  const base = "https://www.hamzaacademy.com";

  const entriesFor = (path, priority) => [
    {
      url: `${base}${path === "/" ? "" : path}`,
      changeFrequency: "weekly",
      priority,
      alternates: {
        languages: {
          bn: `${base}${path === "/" ? "" : path}`,
          en: `${base}/en${path === "/" ? "" : path}`
        }
      }
    },
    {
      url: `${base}/en${path === "/" ? "" : path}`,
      changeFrequency: "weekly",
      priority: priority - 0.05
    }
  ];

  const staticEntries = mainNavRoutes.flatMap((item) => entriesFor(item.href, item.href === "/" ? 1 : 0.7));
  const admissionEntries = entriesFor("/admission", 0.8);
  const programEntries = programs.flatMap((p) => entriesFor(`/programs/${p.slug}`, 0.6));

  return [...staticEntries, ...admissionEntries, ...programEntries];
}

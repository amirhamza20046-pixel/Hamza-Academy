/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./app/**/*.{js,jsx}",
    "./components/**/*.{js,jsx}"
  ],
  theme: {
    extend: {
      colors: {
        navy: {
          DEFAULT: "#0F2A4A",
          50: "#EAF0F6",
          100: "#CBDAE9",
          200: "#9FB9D2",
          300: "#6C93B6",
          400: "#3E6E98",
          500: "#204D74",
          600: "#183C5C",
          700: "#132F49",
          800: "#0F2A4A",
          900: "#0A1C33",
          950: "#071324"
        },
        gold: {
          DEFAULT: "#C9A24B",
          50: "#FBF6EA",
          100: "#F3E5C0",
          200: "#E9D296",
          300: "#DEBE6C",
          400: "#D4AC52",
          500: "#C9A24B",
          600: "#A8813A",
          700: "#82632D",
          800: "#5C4520",
          900: "#372813"
        },
        paper: "#F6F7F5",
        ink: "#1B2430",
        slate2: "#4A5A6A"
      },
      fontFamily: {
        serif: ["var(--font-current-serif)", "Georgia", "serif"],
        sans: ["var(--font-current-sans)", "system-ui", "sans-serif"],
        bangla: ["var(--font-hind-siliguri)", "sans-serif"]
      },
      maxWidth: {
        content: "1180px"
      },
      boxShadow: {
        card: "0 1px 2px rgba(15,42,74,0.06), 0 8px 24px -12px rgba(15,42,74,0.18)"
      }
    }
  },
  plugins: []
};

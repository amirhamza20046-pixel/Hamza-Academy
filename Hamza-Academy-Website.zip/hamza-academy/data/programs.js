// Edit this file to update program content in both languages.
// Each program needs a unique "slug" (used in the URL: /programs/[slug]).
// Every visible field is bilingual: { bn: "...", en: "..." }.

export const programs = [
  {
    slug: "class-1-5-academic",
    classLabel: { bn: "১ম–৫ম শ্রেণি", en: "Class 1–5" },
    shortName: { bn: "১ম–৫ম শ্রেণি একাডেমিক", en: "Class 1–5 Academic" },
    name: { bn: "১ম–৫ম শ্রেণি একাডেমিক প্রোগ্রাম", en: "Class 1–5 Academic Program" },
    tagline: {
      bn: "প্রাথমিক শিক্ষার্থীদের মৌলিক জ্ঞান, নিয়মিত পড়াশোনা ও পরীক্ষার প্রস্তুতি।",
      en: "Foundational knowledge, regular study and exam preparation for primary students."
    },
    target: {
      bn: "১ম থেকে ৫ম শ্রেণির শিক্ষার্থী, যারা মূল বিষয়ে সুশৃঙ্খল পাঠ ও নিয়মিত অনুশীলন চায়।",
      en: "Students of Class 1 to Class 5 who want structured lessons and regular practice in core subjects."
    },
    overview: {
      bn: "প্রাথমিক শিক্ষার্থীদের মৌলিক জ্ঞান, নিয়মিত পড়াশোনা ও পরীক্ষার প্রস্তুতি। জাতীয় পাঠ্যক্রম অনুসরণ করে পড়া, লেখা, গণিত ও সাধারণ বিজ্ঞানে শক্ত ভিত্তি গড়ে তোলা হয়। ক্লাস ছোট ও ইন্টারঅ্যাকটিভ রাখা হয় যাতে প্রতিটি শিক্ষার্থী মনোযোগ পায়।",
      en: "Foundational knowledge, regular study and exam preparation for primary students. Follows the national curriculum and builds strong fundamentals in reading, writing, mathematics and general science. Classes are kept small and interactive so every student receives attention."
    },
    subjects: [
      { bn: "বাংলা", en: "Bangla" },
      { bn: "ইংরেজি", en: "English" },
      { bn: "গণিত", en: "Mathematics" },
      { bn: "সাধারণ বিজ্ঞান", en: "General Science" },
      { bn: "সাধারণ জ্ঞান", en: "General Knowledge" }
    ],
    benefits: [
      { bn: "ব্যক্তিগত মনোযোগের জন্য ছোট, ফোকাসড ব্যাচ", en: "Small, focused batches for individual attention" },
      { bn: "সাপ্তাহিক ওয়ার্কশিট ও অনুশীলনী", en: "Weekly worksheets and practice sheets" },
      { bn: "নিয়মিত ক্লাস টেস্ট ও অভিভাবকদের ফিডব্যাক", en: "Regular class tests with parent feedback" },
      { bn: "রিভিশনের জন্য রেকর্ডেড ক্লাস", en: "Recorded classes available for revision" }
    ],
    method: {
      bn: "সপ্তাহে ৩–৪ দিন Google Meet/Zoom-এ লাইভ অনলাইন ক্লাস, সাথে ডাউনলোডযোগ্য নোট ও অনুশীলনী।",
      en: "Live online classes on Google Meet/Zoom, 3–4 days a week, with downloadable notes and practice sheets."
    },
    icon: "book",
    color: "navy"
  },
  {
    slug: "class-5-scholarship",
    classLabel: { bn: "৫ম শ্রেণি", en: "Class 5" },
    shortName: { bn: "৫ম শ্রেণি বৃত্তি প্রস্তুতি", en: "Class 5 Scholarship Prep" },
    name: { bn: "৫ম শ্রেণি বৃত্তি প্রস্তুতি প্রোগ্রাম", en: "Class 5 Scholarship Preparation Program" },
    tagline: {
      bn: "বৃত্তি পরীক্ষার জন্য বিষয়ভিত্তিক প্রস্তুতি, মডেল টেস্ট ও বিশেষ অনুশীলন।",
      en: "Subject-wise preparation, model tests and focused practice for the scholarship exam."
    },
    target: {
      bn: "৫ম শ্রেণির শিক্ষার্থী যারা প্রাথমিক বৃত্তি পরীক্ষায় ভালো ফল করতে চায়।",
      en: "Class 5 students aiming for strong performance in the primary scholarship examination."
    },
    overview: {
      bn: "বৃত্তি পরীক্ষার জন্য বিষয়ভিত্তিক প্রস্তুতি, মডেল টেস্ট ও বিশেষ অনুশীলন। টপিকভিত্তিক প্রশ্নব্যাংক, সময়ভিত্তিক মডেল টেস্ট এবং উত্তরপত্র আলোচনা ক্লাসের মাধ্যমে শিক্ষার্থীদের পূর্ণাঙ্গ প্রস্তুতি করানো হয়।",
      en: "Subject-wise preparation, model tests and focused practice for the scholarship exam. Topic-wise question banks, timed model tests and answer-key discussion classes prepare students thoroughly."
    },
    subjects: [
      { bn: "বাংলা", en: "Bangla" },
      { bn: "ইংরেজি", en: "English" },
      { bn: "গণিত", en: "Mathematics" },
      { bn: "সাধারণ বিজ্ঞান", en: "General Science" },
      { bn: "সাধারণ জ্ঞান", en: "General Knowledge" },
      { bn: "মানসিক দক্ষতা", en: "Mental Ability" }
    ],
    benefits: [
      { bn: "টপিকভিত্তিক প্রশ্নব্যাংক ও অনুশীলনী", en: "Topic-wise question bank and practice sheets" },
      { bn: "র‍্যাংক শিটসহ সাপ্তাহিক সময়ভিত্তিক মডেল টেস্ট", en: "Weekly timed model tests with rank sheets" },
      { bn: "বিস্তারিত উত্তরপত্র আলোচনা ক্লাস", en: "Detailed answer-key discussion classes" },
      { bn: "পরীক্ষার আগে সন্দেহ নিরসন সেশন", en: "Doubt-solving sessions before exams" }
    ],
    method: {
      bn: "লাইভ অনলাইন ক্লাসের সাথে নির্ধারিত মডেল টেস্ট; প্রতিটি টেস্টের পর উত্তরপত্র ও মেধাতালিকা প্রকাশ করা হয়।",
      en: "Live online classes combined with scheduled model tests; answer keys and merit lists are published after every test."
    },
    icon: "scholarship",
    color: "gold"
  },
  {
    slug: "class-6-8-academic",
    classLabel: { bn: "৬ষ্ঠ–৮ম শ্রেণি", en: "Class 6–8" },
    shortName: { bn: "৬ষ্ঠ–৮ম শ্রেণি একাডেমিক", en: "Class 6–8 Academic" },
    name: { bn: "৬ষ্ঠ–৮ম শ্রেণি একাডেমিক প্রোগ্রাম", en: "Class 6–8 Academic Program" },
    tagline: {
      bn: "স্কুলের নিয়মিত পড়াশোনা, দুর্বলতা দূরীকরণ ও ভালো ফলাফলের জন্য পরিকল্পিত ক্লাস।",
      en: "Planned classes for regular school study, weakness recovery and strong results."
    },
    target: {
      bn: "৬ষ্ঠ, ৭ম ও ৮ম শ্রেণির শিক্ষার্থী যারা সব প্রধান বিষয়ে ধারাবাহিক একাডেমিক সহায়তা চায়।",
      en: "Students of Class 6, 7 and 8 who want consistent academic support across major subjects."
    },
    overview: {
      bn: "স্কুলের নিয়মিত পড়াশোনা, দুর্বলতা দূরীকরণ ও ভালো ফলাফলের জন্য পরিকল্পিত ক্লাস। বিষয়ভিত্তিক লাইভ ক্লাস, অধ্যায়ভিত্তিক নোট এবং নিয়মিত মূল্যায়নের মাধ্যমে শিক্ষার্থীরা সারা বছর আত্মবিশ্বাসী থাকে।",
      en: "Planned classes for regular school study, weakness recovery and strong results. Subject-wise live classes, chapter-based notes and regular assessments keep students confident throughout the year."
    },
    subjects: [
      { bn: "বাংলা", en: "Bangla" },
      { bn: "ইংরেজি", en: "English" },
      { bn: "গণিত", en: "Mathematics" },
      { bn: "বিজ্ঞান", en: "Science" },
      { bn: "সামাজিক বিজ্ঞান", en: "Social Science" }
    ],
    benefits: [
      { bn: "বিষয়ভিত্তিক লাইভ ক্লাস", en: "Subject-wise live classes" },
      { bn: "অধ্যায়ভিত্তিক নোট ও অনুশীলনী", en: "Chapter-based notes and practice" },
      { bn: "নিয়মিত ক্লাস টেস্ট ও অগ্রগতি রিপোর্ট", en: "Regular class tests and progress reports" },
      { bn: "দুর্বল অংশ পুনরায় শেখানোর সুযোগ", en: "Re-teaching support for weak areas" }
    ],
    method: {
      bn: "সপ্তাহে নির্দিষ্ট দিনে লাইভ অনলাইন ক্লাস, সাথে রেকর্ডেড সেশন ও স্টাডি ম্যাটেরিয়াল।",
      en: "Live online classes on fixed days each week, supported by recorded sessions and study materials."
    },
    icon: "academic",
    color: "navy"
  },
  {
    slug: "class-6-cadet",
    classLabel: { bn: "৬ষ্ঠ শ্রেণি", en: "Class 6" },
    shortName: { bn: "৬ষ্ঠ শ্রেণি ক্যাডেট ভর্তি", en: "Class 6 Cadet Admission" },
    name: { bn: "৬ষ্ঠ শ্রেণি ক্যাডেট কলেজ ভর্তি প্রস্তুতি", en: "Class 6 Cadet College Admission Preparation" },
    tagline: {
      bn: "বাংলা, ইংরেজি, সাধারণ জ্ঞান ও ভর্তি পরীক্ষার পূর্ণাঙ্গ প্রস্তুতি।",
      en: "Complete preparation in Bangla, English, General Knowledge and the admission exam."
    },
    target: {
      bn: "৬ষ্ঠ শ্রেণিতে ক্যাডেট কলেজে ভর্তি হতে ইচ্ছুক শিক্ষার্থী।",
      en: "Students aiming for admission into Cadet College at Class 6."
    },
    overview: {
      bn: "বাংলা, ইংরেজি, সাধারণ জ্ঞান ও ভর্তি পরীক্ষার পূর্ণাঙ্গ প্রস্তুতি। পরীক্ষার কাঠামো অনুযায়ী বিষয়ভিত্তিক ক্লাস, মডেল টেস্ট ও বিশেষ অনুশীলনের মাধ্যমে শিক্ষার্থীদের প্রস্তুত করা হয়।",
      en: "Complete preparation in Bangla, English, General Knowledge and the admission exam. Subject-wise classes, model tests and focused practice aligned with the exam structure prepare students thoroughly."
    },
    subjects: [
      { bn: "বাংলা", en: "Bangla" },
      { bn: "ইংরেজি", en: "English" },
      { bn: "গণিত", en: "Mathematics" },
      { bn: "সাধারণ জ্ঞান", en: "General Knowledge" },
      { bn: "মানসিক দক্ষতা", en: "Mental Ability" }
    ],
    benefits: [
      { bn: "ভর্তি পরীক্ষার কাঠামো অনুযায়ী ক্লাস", en: "Classes aligned with admission exam structure" },
      { bn: "নিয়মিত মডেল টেস্ট ও র‍্যাংক শিট", en: "Regular model tests with rank sheets" },
      { bn: "উত্তরপত্র আলোচনা ও সন্দেহ নিরসন", en: "Answer discussion and doubt clearing" },
      { bn: "অভিভাবকদের সাথে অগ্রগতি শেয়ার", en: "Progress shared with guardians" }
    ],
    method: {
      bn: "লাইভ অনলাইন ক্লাস, নির্ধারিত মডেল টেস্ট এবং পরীক্ষার আগে বিশেষ রিভিশন সেশন।",
      en: "Live online classes, scheduled model tests and special revision sessions before the exam."
    },
    icon: "cadet",
    color: "gold"
  }
];

// Add a link (PDF, Google Drive, or image) for each result entry.
// This keeps the Results page simple — no database or result-management
// system needed. Titles/programs/labels are bilingual.

export const results = [
  {
    id: "r1",
    title: { bn: "আগস্ট ২০২৬ — মাসিক মডেল টেস্ট ফলাফল", en: "August 2026 — Monthly Model Test Result" },
    program: { bn: "৫ম শ্রেণি বৃত্তি প্রোগ্রাম", en: "Class 5 Scholarship Program" },
    date: "2026-08-30",
    linkLabel: { bn: "ফলাফল শিট দেখুন", en: "View result sheet" },
    link: "#"
  },
  {
    id: "r2",
    title: { bn: "আগস্ট ২০২৬ — মাসিক মডেল টেস্ট ফলাফল", en: "August 2026 — Monthly Model Test Result" },
    program: { bn: "৬ষ্ঠ শ্রেণি ক্যাডেট ভর্তি প্রোগ্রাম", en: "Class 6 Cadet Admission Program" },
    date: "2026-08-28",
    linkLabel: { bn: "ফলাফল শিট দেখুন", en: "View result sheet" },
    link: "#"
  },
  {
    id: "r3",
    title: { bn: "অর্ধ-বার্ষিক পরীক্ষা — মেধাতালিকা", en: "Half-Yearly Exam — Merit List" },
    program: { bn: "৬ষ্ঠ–৮ম শ্রেণি একাডেমিক প্রোগ্রাম", en: "Class 6–8 Academic Program" },
    date: "2026-08-15",
    linkLabel: { bn: "মেধাতালিকা দেখুন", en: "View merit list" },
    link: "#"
  },
  {
    id: "r4",
    title: { bn: "ক্লাস টেস্ট ফলাফল — সেট ৫", en: "Class Test Result — Set 5" },
    program: { bn: "১ম–৫ম শ্রেণি একাডেমিক প্রোগ্রাম", en: "Class 1–5 Academic Program" },
    date: "2026-08-10",
    linkLabel: { bn: "ফলাফল শিট দেখুন", en: "View result sheet" },
    link: "#"
  }
];

export const topPerformers = [
  {
    id: "tp1",
    name: { bn: "আরিফা রহমান", en: "Arifa Rahman" },
    program: { bn: "৫ম শ্রেণি বৃত্তি", en: "Class 5 Scholarship" },
    note: { bn: "১ম স্থান — আগস্ট মডেল টেস্ট", en: "1st position — August model test" }
  },
  {
    id: "tp2",
    name: { bn: "তানভীর আহমেদ", en: "Tanvir Ahmed" },
    program: { bn: "৬ষ্ঠ শ্রেণি ক্যাডেট ভর্তি", en: "Class 6 Cadet Admission" },
    note: { bn: "২য় স্থান — আগস্ট মডেল টেস্ট", en: "2nd position — August model test" }
  },
  {
    id: "tp3",
    name: { bn: "নুসরাত জাহান", en: "Nusrat Jahan" },
    program: { bn: "৬ষ্ঠ–৮ম শ্রেণি একাডেমিক", en: "Class 6–8 Academic" },
    note: { bn: "শীর্ষ নম্বরপ্রাপ্ত — অর্ধ-বার্ষিক পরীক্ষা", en: "Top scorer — Half-yearly exam" }
  }
];

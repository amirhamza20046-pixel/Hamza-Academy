export const testimonials = [
  {
    id: "ts1",
    quote: {
      bn: "প্লেসহোল্ডার মতামত — হামজা একাডেমির অনলাইন ক্লাসের অভিজ্ঞতা নিয়ে একজন অভিভাবকের প্রকৃত মন্তব্য দিয়ে প্রতিস্থাপন করুন।",
      en: "Placeholder testimonial — replace with a real quote from a parent about their experience with Hamza Academy's online classes."
    },
    author: { bn: "অভিভাবকের নাম প্লেসহোল্ডার", en: "Parent Name Placeholder" },
    context: { bn: "অভিভাবক, ৫ম শ্রেণি বৃত্তি প্রোগ্রাম", en: "Guardian, Class 5 Scholarship Program" }
  },
  {
    id: "ts2",
    quote: {
      bn: "প্লেসহোল্ডার মতামত — ক্লাস ও ম্যাটেরিয়াল কীভাবে সাহায্য করেছে তা নিয়ে একজন শিক্ষার্থীর প্রকৃত মন্তব্য দিয়ে প্রতিস্থাপন করুন।",
      en: "Placeholder testimonial — replace with a real quote from a student about how the classes and materials helped them."
    },
    author: { bn: "শিক্ষার্থীর নাম প্লেসহোল্ডার", en: "Student Name Placeholder" },
    context: { bn: "শিক্ষার্থী, ৬ষ্ঠ–৮ম শ্রেণি একাডেমিক প্রোগ্রাম", en: "Student, Class 6–8 Academic Program" }
  },
  {
    id: "ts3",
    quote: {
      bn: "প্লেসহোল্ডার মতামত — শিক্ষার মান বা পরীক্ষার ফলাফল নিয়ে একটি প্রকৃত মন্তব্য দিয়ে প্রতিস্থাপন করুন।",
      en: "Placeholder testimonial — replace with a real quote about the teaching quality or exam results."
    },
    author: { bn: "অভিভাবকের নাম প্লেসহোল্ডার", en: "Parent Name Placeholder" },
    context: { bn: "অভিভাবক, ৬ষ্ঠ শ্রেণি ক্যাডেট ভর্তি প্রোগ্রাম", en: "Guardian, Class 6 Cadet Admission Program" }
  }
];

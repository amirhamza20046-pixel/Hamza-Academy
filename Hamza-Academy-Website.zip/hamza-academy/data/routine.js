// Editable weekly class routine. Update rows here to change the routine table.
// Program/subject/topic/day/platform are bilingual: { bn: "...", en: "..." }.

export const routine = [
  {
    date: "2026-09-15",
    day: { bn: "মঙ্গলবার", en: "Tuesday" },
    program: { bn: "১ম–৫ম শ্রেণি একাডেমিক", en: "Class 1–5 Academic" },
    subject: { bn: "গণিত", en: "Mathematics" },
    topic: { bn: "নামতা ও কথায় প্রকাশিত সমস্যা", en: "Multiplication tables & word problems" },
    time: "4:00 PM – 5:00 PM",
    platform: { bn: "Google Meet", en: "Google Meet" }
  },
  {
    date: "2026-09-15",
    day: { bn: "মঙ্গলবার", en: "Tuesday" },
    program: { bn: "৬ষ্ঠ শ্রেণি ক্যাডেট ভর্তি", en: "Class 6 Cadet Admission" },
    subject: { bn: "সাধারণ জ্ঞান", en: "General Knowledge" },
    topic: { bn: "বাংলাদেশ: নদী ও ভূগোল", en: "Bangladesh: rivers and geography" },
    time: "5:30 PM – 6:30 PM",
    platform: { bn: "Zoom", en: "Zoom" }
  },
  {
    date: "2026-09-16",
    day: { bn: "বুধবার", en: "Wednesday" },
    program: { bn: "৬ষ্ঠ–৮ম শ্রেণি একাডেমিক", en: "Class 6–8 Academic" },
    subject: { bn: "ইংরেজি", en: "English" },
    topic: { bn: "Tense ও sentence transformation", en: "Tense & sentence transformation" },
    time: "4:00 PM – 5:00 PM",
    platform: { bn: "Google Meet", en: "Google Meet" }
  },
  {
    date: "2026-09-16",
    day: { bn: "বুধবার", en: "Wednesday" },
    program: { bn: "৫ম শ্রেণি বৃত্তি", en: "Class 5 Scholarship" },
    subject: { bn: "মানসিক দক্ষতা", en: "Mental Ability" },
    topic: { bn: "সিরিজ সমাপ্তি ও প্যাটার্ন সনাক্তকরণ", en: "Series completion & pattern recognition" },
    time: "6:00 PM – 7:00 PM",
    platform: { bn: "Zoom", en: "Zoom" }
  },
  {
    date: "2026-09-17",
    day: { bn: "বৃহস্পতিবার", en: "Thursday" },
    program: { bn: "১ম–৫ম শ্রেণি একাডেমিক", en: "Class 1–5 Academic" },
    subject: { bn: "বাংলা", en: "Bangla" },
    topic: { bn: "ব্যাকরণ: বাক্যের প্রকারভেদ", en: "Grammar: sentence types" },
    time: "4:00 PM – 5:00 PM",
    platform: { bn: "Google Meet", en: "Google Meet" }
  },
  {
    date: "2026-09-17",
    day: { bn: "বৃহস্পতিবার", en: "Thursday" },
    program: { bn: "৬ষ্ঠ–৮ম শ্রেণি একাডেমিক", en: "Class 6–8 Academic" },
    subject: { bn: "বিজ্ঞান", en: "Science" },
    topic: { bn: "অধ্যায় ৪: বল ও গতি", en: "Chapter 4: Force and motion" },
    time: "5:30 PM – 6:30 PM",
    platform: { bn: "Google Meet", en: "Google Meet" }
  },
  {
    date: "2026-09-18",
    day: { bn: "শুক্রবার", en: "Friday" },
    program: { bn: "৬ষ্ঠ শ্রেণি ক্যাডেট ভর্তি", en: "Class 6 Cadet Admission" },
    subject: { bn: "গণিত", en: "Mathematics" },
    topic: { bn: "পূর্ণাঙ্গ মডেল টেস্ট — সেট ৭", en: "Full model test — Set 7" },
    time: "10:00 AM – 11:30 AM",
    platform: { bn: "Zoom", en: "Zoom" }
  }
];

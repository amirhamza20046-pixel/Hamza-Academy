// Replace "link" with a real PDF / Google Drive link for each resource.
// Titles/program/category labels are bilingual.

export const materialCategories = [
  {
    id: "notes",
    label: { bn: "ক্লাস নোট", en: "Class Notes" },
    items: [
      {
        id: "m1",
        title: { bn: "৫ম শ্রেণি — গণিত: ভগ্নাংশ (অধ্যায় নোট)", en: "Class 5 — Mathematics: Fractions (Chapter Notes)" },
        program: { bn: "১ম–৫ম শ্রেণি একাডেমিক", en: "Class 1–5 Academic" },
        link: "#"
      },
      {
        id: "m2",
        title: { bn: "৭ম শ্রেণি — ইংরেজি ব্যাকরণ: Tense চার্ট", en: "Class 7 — English Grammar: Tense Chart" },
        program: { bn: "৬ষ্ঠ–৮ম শ্রেণি একাডেমিক", en: "Class 6–8 Academic" },
        link: "#"
      }
    ]
  },
  {
    id: "practice",
    label: { bn: "অনুশীলনী", en: "Practice Sheets" },
    items: [
      {
        id: "m3",
        title: { bn: "বৃত্তি — মানসিক দক্ষতা অনুশীলন সেট ৪", en: "Scholarship — Mental Ability Practice Set 4" },
        program: { bn: "৫ম শ্রেণি বৃত্তি", en: "Class 5 Scholarship" },
        link: "#"
      },
      {
        id: "m4",
        title: { bn: "ক্যাডেট ভর্তি — সাধারণ জ্ঞান অনুশীলন সেট ৬", en: "Cadet Admission — General Knowledge Practice Set 6" },
        program: { bn: "৬ষ্ঠ শ্রেণি ক্যাডেট ভর্তি", en: "Class 6 Cadet Admission" },
        link: "#"
      }
    ]
  },
  {
    id: "model-tests",
    label: { bn: "মডেল টেস্ট", en: "Model Tests" },
    items: [
      {
        id: "m5",
        title: { bn: "ক্যাডেট ভর্তি — পূর্ণাঙ্গ মডেল টেস্ট ৭ (উত্তরপত্রসহ)", en: "Cadet Admission — Full Model Test 7 (with answer key)" },
        program: { bn: "৬ষ্ঠ শ্রেণি ক্যাডেট ভর্তি", en: "Class 6 Cadet Admission" },
        link: "#"
      },
      {
        id: "m6",
        title: { bn: "বৃত্তি — পূর্ণাঙ্গ মডেল টেস্ট ৫ (উত্তরপত্রসহ)", en: "Scholarship — Full Model Test 5 (with answer key)" },
        program: { bn: "৫ম শ্রেণি বৃত্তি", en: "Class 5 Scholarship" },
        link: "#"
      }
    ]
  },
  {
    id: "suggestions",
    label: { bn: "সাজেশন", en: "Suggestions" },
    items: [
      {
        id: "m7",
        title: { bn: "৮ম শ্রেণি — অর্ধ-বার্ষিক পরীক্ষার সাজেশন", en: "Class 8 — Half-Yearly Exam Suggestion" },
        program: { bn: "৬ষ্ঠ–৮ম শ্রেণি একাডেমিক", en: "Class 6–8 Academic" },
        link: "#"
      }
    ]
  }
];

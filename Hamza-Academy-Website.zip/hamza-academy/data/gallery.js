// Replace "label" placeholders with real photos later (see /public/images).
// Until then, each item renders as a labelled placeholder tile.

export const galleryItems = [
  { id: "g1", label: { bn: "অনলাইন ক্লাস সেশন", en: "Online Class Session" }, category: { bn: "অনলাইন ক্লাস", en: "Online Classes" } },
  { id: "g2", label: { bn: "মডেল টেস্ট", en: "Model Test" }, category: { bn: "পরীক্ষা", en: "Exams" } },
  { id: "g3", label: { bn: "শিক্ষার্থী কার্যক্রম", en: "Student Activity" }, category: { bn: "শিক্ষার্থী কার্যক্রম", en: "Student Activities" } },
  { id: "g4", label: { bn: "পুরস্কার অনুষ্ঠান", en: "Award Ceremony" }, category: { bn: "পুরস্কার", en: "Awards" } },
  { id: "g5", label: { bn: "বিশেষ অনুষ্ঠান", en: "Special Program" }, category: { bn: "বিশেষ অনুষ্ঠান", en: "Special Programs" } },
  { id: "g6", label: { bn: "অনলাইন ক্লাস সেশন", en: "Online Class Session" }, category: { bn: "অনলাইন ক্লাস", en: "Online Classes" } },
  { id: "g7", label: { bn: "পরীক্ষার প্রস্তুতি", en: "Exam Preparation" }, category: { bn: "পরীক্ষা", en: "Exams" } },
  { id: "g8", label: { bn: "শিক্ষার্থী কার্যক্রম", en: "Student Activity" }, category: { bn: "শিক্ষার্থী কার্যক্রম", en: "Student Activities" } }
];

// Non-translatable / shared facts (name, phone, socials) plus bilingual
// nav labels are pulled from lib/dictionaries.js — this file only holds the
// raw facts that stay the same in both languages.
// Contact details left ready for later update (no invented numbers/links).

export const site = {
  name: "HAMZA ACADEMY",
  nameBn: "হামজা একাডেমি",
  phone: "শীঘ্রই আপডেট হবে",
  email: "info@hamzaacademy.com",
  address: "Address to be updated — Dhaka, Bangladesh",
  addressBn: "ঠিকানা শীঘ্রই আপডেট হবে — ঢাকা, বাংলাদেশ",
  social: {
    facebook: "#",
    instagram: "#",
    youtube: "#"
  }
};

// Route list used to build the nav menu and footer links. "key" maps into
// dictionaries.nav for the label; "href" is locale-agnostic (see lib/paths.js).
export const mainNavRoutes = [
  { key: "home", href: "/" },
  { key: "about", href: "/about" },
  { key: "programs", href: "/programs" },
  { key: "routine", href: "/routine" },
  { key: "notices", href: "/notices" },
  { key: "onlineClasses", href: "/online-classes" },
  { key: "materials", href: "/materials" },
  { key: "results", href: "/results" },
  { key: "teachers", href: "/teachers" },
  { key: "gallery", href: "/gallery" },
  { key: "contact", href: "/contact" }
];

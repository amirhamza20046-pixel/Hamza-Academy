// Replace with real teacher information and photos when ready.
// "initials" renders a placeholder avatar until a real photo is added.
// Every visible field is bilingual: { bn: "...", en: "..." }.

export const teachers = [
  {
    id: "t1",
    name: { bn: "শিক্ষকের নাম", en: "Teacher Name" },
    initials: "TN",
    designation: { bn: "প্রতিষ্ঠাতা ও পরিচালক", en: "Founder & Director" },
    subject: { bn: "গণিত ও ভর্তি কোচিং", en: "Mathematics & Admission Coaching" },
    bio: {
      bn: "শিক্ষকের বিস্তারিত পরিচিতি এখানে যোগ করা হবে।",
      en: "Teacher biography will be added here."
    }
  },
  {
    id: "t2",
    name: { bn: "শিক্ষকের নাম", en: "Teacher Name" },
    initials: "TN",
    designation: { bn: "সিনিয়র বিষয় শিক্ষক", en: "Senior Subject Teacher" },
    subject: { bn: "ইংরেজি", en: "English" },
    bio: {
      bn: "শিক্ষকের বিস্তারিত পরিচিতি এখানে যোগ করা হবে।",
      en: "Teacher biography will be added here."
    }
  },
  {
    id: "t3",
    name: { bn: "শিক্ষকের নাম", en: "Teacher Name" },
    initials: "TN",
    designation: { bn: "বিষয় শিক্ষক", en: "Subject Teacher" },
    subject: { bn: "বাংলা", en: "Bangla" },
    bio: {
      bn: "শিক্ষকের বিস্তারিত পরিচিতি এখানে যোগ করা হবে।",
      en: "Teacher biography will be added here."
    }
  },
  {
    id: "t4",
    name: { bn: "শিক্ষকের নাম", en: "Teacher Name" },
    initials: "TN",
    designation: { bn: "বিষয় শিক্ষক", en: "Subject Teacher" },
    subject: { bn: "সাধারণ বিজ্ঞান", en: "General Science" },
    bio: {
      bn: "শিক্ষকের বিস্তারিত পরিচিতি এখানে যোগ করা হবে।",
      en: "Teacher biography will be added here."
    }
  }
];

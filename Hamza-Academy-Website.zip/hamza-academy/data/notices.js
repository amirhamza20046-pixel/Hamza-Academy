// Add a new notice to the top of this array to publish it.
// "type" controls the small colour tag shown on the notice card and is
// translated via the "typeLabel" object.

export const notices = [
  {
    id: "n1",
    date: "2026-09-20",
    type: "Admission",
    typeLabel: { bn: "ভর্তি", en: "Admission" },
    title: {
      bn: "সকল প্রোগ্রামে ২০২৬ শরৎকালীন ভর্তি চলছে",
      en: "Autumn 2026 admission now open for all programs"
    },
    details: {
      bn: "১ম–৫ম শ্রেণি একাডেমিক, ৫ম শ্রেণি বৃত্তি প্রস্তুতি, ৬ষ্ঠ–৮ম শ্রেণি একাডেমিক এবং ৬ষ্ঠ শ্রেণি ক্যাডেট কলেজ ভর্তি প্রস্তুতিের ভর্তি এখন চলছে। প্রতিটি ব্যাচে আসন সীমিত।",
      en: "Admission for the Class 1–5 Academic, Class 5 Scholarship, Class 6–8 Academic and Class 6 Cadet Admission programs is now open. Seats are limited per batch."
    }
  },
  {
    id: "n2",
    date: "2026-09-18",
    type: "Batch",
    typeLabel: { bn: "ব্যাচ", en: "Batch" },
    title: {
      bn: "৬ষ্ঠ শ্রেণি ক্যাডেট কলেজ ভর্তি প্রস্তুতিের নতুন ব্যাচ শুরু",
      en: "New batch starting for Class 6 Cadet College Admission Preparation"
    },
    details: {
      bn: "আগামী সপ্তাহে একটি নতুন ব্যাচ শুরু হচ্ছে। আগ্রহী শিক্ষার্থীদের যত দ্রুত সম্ভব ভর্তির ফর্ম জমা দিতে হবে।",
      en: "A new batch begins next week. Interested students should submit the admission enquiry form as soon as possible."
    }
  },
  {
    id: "n3",
    date: "2026-09-15",
    type: "Exam",
    typeLabel: { bn: "পরীক্ষা", en: "Exam" },
    title: {
      bn: "মাসিক মডেল টেস্টের সময়সূচি প্রকাশিত",
      en: "Monthly model test schedule published"
    },
    details: {
      bn: "সকল প্রোগ্রামের মাসিক মডেল টেস্টের রুটিন প্রকাশ করা হয়েছে। সঠিক তারিখ ও সময়ের জন্য ক্লাস রুটিন পৃষ্ঠা দেখুন।",
      en: "The monthly model test routine for all programs has been published. Please check the Class Routine page for exact dates and times."
    }
  },
  {
    id: "n4",
    date: "2026-09-10",
    type: "Holiday",
    typeLabel: { bn: "ছুটি", en: "Holiday" },
    title: {
      bn: "ঈদের ছুটিতে ক্লাস বন্ধ থাকবে",
      en: "Classes suspended for Eid holidays"
    },
    details: {
      bn: "ছুটির সময় সকল অনলাইন ক্লাস বন্ধ থাকবে। ছুটি শেষে নিয়মিত ক্লাস রুটিন অনুযায়ী আবার শুরু হবে।",
      en: "All online classes will remain suspended during the holiday period. Regular classes will resume as per the routine afterward."
    }
  },
  {
    id: "n5",
    date: "2026-09-05",
    type: "General",
    typeLabel: { bn: "সাধারণ", en: "General" },
    title: {
      bn: "অনলাইন ক্লাসে জয়েন করার নির্দেশিকা হালনাগাদ করা হয়েছে",
      en: "Guideline for joining online classes updated"
    },
    details: {
      bn: "Google Meet/Zoom সেশনে জয়েন করার ধাপে ধাপে হালনাগাদ নির্দেশিকার জন্য অনলাইন ক্লাস পৃষ্ঠা দেখুন।",
      en: "Please see the Online Classes page for the updated step-by-step guide on joining Google Meet/Zoom sessions."
    }
  }
];

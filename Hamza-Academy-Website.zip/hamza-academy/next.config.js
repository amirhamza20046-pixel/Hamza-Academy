/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  images: {
    // Using local/inline assets only (no external image domains) to keep
    // hosting free/low-cost. Add domains here later if you switch to a
    // photo CDN (e.g. Cloudinary) for teacher photos / gallery images.
    unoptimized: false
  }
};

module.exports = nextConfig;
